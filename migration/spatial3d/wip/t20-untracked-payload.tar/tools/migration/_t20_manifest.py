#!/usr/bin/env python3
"""Append T20 terrain fixture entries to migration/oracle-manifest.json.

Each entry names every file it carries with byte count and SHA-256; float64
payloads also declare dtype/shape/order like the existing random/ entries.
Idempotent: replaces prior terrain/ entries on re-run.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
FIX = REPO / "tests" / "fixtures" / "migration" / "terrain"
MANIFEST = REPO / "migration" / "oracle-manifest.json"

# (fixture name, [files], notes)
ENTRIES: list[tuple[str, list[str], str]] = [
    ("terrain/obstacle-elevations",
     ["obstacle_elevations.json"] +
     [f"obstacle_{n}.f64" for n in (
         "square_edge", "square_edge_authored", "pothole", "washboard9",
         "washboard20", "g_out", "drop", "drop_ramp", "kicker",
         "kicker_default", "roots2029", "rock1701", "rock3301", "bump",
         "trapezoid", "trapezoid_sharp", "sloped_pothole",
         "sloped_pothole_wide_edge", "bowl_pothole", "road_roughness",
         "stepped_climb", "stepped_climb_short")],
     "per-class elevation(s) grids with param records, labels, datum "
     "shifts and lengths (obstacles.py)"),
    ("terrain/rock-garden-nodes",
     ["rock_nodes_seed1701.f64", "rock_nodes_seed3301.f64",
      "rock_nodes_seed0.f64", "rock_nodes_rough17.f64",
      "roots_centres_2029.f64"],
     "RockGarden._nodes()/Roots.bump_centres_m() — seeded node grids: "
     "NumpyRng draws + scipy gaussian_filter1d smoothing + taper"),
    ("terrain/track-fields",
     ["track_fields.json"] +
     [f"{n}_profile_dense.f64" for n in (
         "flat", "single_edge", "washboard_only", "climb_steps",
         "enduro_aggressive", "road_smooth", "road_worn", "road_broken")],
     "build_profile over arange(0, L+res/2, res) per preset plus "
     "datum_shift/extent/markers/surface-map scalars (profile.py)"),
    ("terrain/road-obstacles",
     ["road_obstacles.json"],
     "generate_road layouts for the three built-in road specs and a "
     "mixed-shape spec with reserved intervals (road.py)"),
    ("terrain/grade",
     ["grade.f64"],
     "GradeProfile slope/elevation pairs incl. out-of-domain queries "
     "(grade.py)"),
    ("terrain/surface",
     ["surface.json"],
     "SurfaceSpec registry fields, mu() probe grid, slip_stiffness_n "
     "loads and SurfaceMap half-open interval probes (surface.py)"),
    ("terrain/heightfield",
     ["heightfield.json", "field_data_flat.f64", "field_data_enduro.f64",
      "field_data_long.f64", "track_x_default.f64"],
     "HeightFieldSpec defaults/derived specs, geometry scalars, "
     "build_field_data payloads and the default track_x grid "
     "(heightfield.py)"),
    ("terrain/wheelpath",
     ["wheelpath.json"] +
     [f"wheelpath_{n}.f64" for n in (
         "pothole", "bump", "rock1701", "drop_ramp", "kicker")],
     "wheel_centre_path envelopes plus effective drop/rise and "
     "bridged_drop scalars (wheelpath.py)"),
    ("terrain/contact-safety",
     ["contact_safety.json"],
     "single_contact_hazards strings, closed-form guards and "
     "concave_span_deg values (contact_safety.py)"),
    ("terrain/profile-kernels",
     ["profile_kernels.json"],
     "SignedProfile.query/height and ProfileQuery.contact rows proving "
     "the reuse contract against the existing tyre kernels "
     "(profile_distance.py, contact_profile.py)"),
    ("terrain/validation",
     ["validation.json"],
     "exact ValueError/KeyError kinds and message text across the "
     "invalid-input domain plus scalar property captures"),
]


def main() -> int:
    manifest = json.loads(MANIFEST.read_text())
    fixtures = [f for f in manifest["fixtures"]
                if not f.get("group") == "terrain"]
    for name, files, notes in ENTRIES:
        declared = []
        for rel in files:
            data = (FIX / rel).read_bytes()
            entry = {
                "bytes": len(data),
                "path": f"terrain/{rel}",
                "sha256": hashlib.sha256(data).hexdigest(),
            }
            if rel.endswith(".f64"):
                entry.update({
                    "dtype": "<f8",
                    "order": "C",
                    "shape": [len(data) // 8],
                })
            declared.append(entry)
        fixtures.append({
            "comparison": "B",
            "expected": {"kind": "accepted"},
            "files": declared,
            "group": "terrain",
            "inputs": [],
            "name": name,
            "notes": notes,
            "produced_by": "tools/migration/_t20_capture.py against the "
                           "T20-owned terrain oracle modules",
            "recipe": "RCP-03",
        })
    manifest["fixtures"] = fixtures
    MANIFEST.write_text(json.dumps(manifest, indent=1, sort_keys=True) + "\n")
    print(f"wrote {len(ENTRIES)} terrain entries "
          f"({sum(len(f) for _, f, _ in ENTRIES)} files)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
