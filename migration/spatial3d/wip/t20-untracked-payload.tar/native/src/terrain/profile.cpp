// profile.cpp — GradeProfile, TrackSpec and build_profile (grade.py,
// profile.py) plus the road.py procedural generator that the T20 ledger
// assigns to this task (obstacle *formulas* live in obstacles.cpp; this
// file owns the sequencing: draws, placement and TrackSpec assembly).
//
// Numeric contract:
//   GradeProfile::elevation — np.diff/np.cumsum trapezoidal knots,
//     searchsorted-right interval index, .5*change*dx*dx extension and
//     the two np.where endpoint branches, in source order.
//   build_profile — the oracle's masked per-obstacle writes lowered to
//     per-element predicates (identical because every mask is applied
//     to every element and the writes are disjoint); datum accumulates
//     with plain fl adds.
//   generate_road — the NumpyRng draw sequence of road.py verbatim:
//     per-defect _choose/_make triples first, stable largest-first
//     placement, then roughness segment seeds.
#include "profile.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

#include "random/numpy_compat.hpp"

namespace bike::terrain {

// ---------------------------------------------------------------------------
// grade.py
// ---------------------------------------------------------------------------

GradeProfile::GradeProfile(std::vector<std::array<double, 2>> knots)
    : knots_(std::move(knots)) {
    if (knots_.size() < 2)
        throw std::invalid_argument(
                "grade needs at least two station/grade pairs");
    for (const auto &p : knots_)
        for (const double v : p)
            if (!std::isfinite(v))
                throw std::invalid_argument(
                        "grade knots must be finite real numbers");
    if (knots_.front()[0] != 0.0)
        throw std::invalid_argument(
                "grade stations must start at zero and strictly "
                "increase");
    for (std::size_t i = 1; i < knots_.size(); ++i)
        if (knots_[i][0] <= knots_[i - 1][0])
            throw std::invalid_argument(
                    "grade stations must start at zero and strictly "
                    "increase");
}

double GradeProfile::slope(double x) const {
    if (!std::isfinite(x))
        throw std::invalid_argument("grade query must be finite");
    std::vector<double> stations, grades;
    stations.reserve(knots_.size());
    grades.reserve(knots_.size());
    for (const auto &p : knots_) {
        stations.push_back(p[0]);
        grades.push_back(p[1]);
    }
    return detail::np_interp(x, stations, grades);
}

std::vector<double>
GradeProfile::slope(std::span<const double> x) const {
    std::vector<double> out(x.size());
    for (std::size_t i = 0; i < x.size(); ++i) out[i] = slope(x[i]);
    return out;
}

std::vector<double>
GradeProfile::elevation(std::span<const double> x) const {
    std::vector<double> out(x.size());
    for (std::size_t i = 0; i < x.size(); ++i)
        out[i] = elevation(x[i]);
    return out;
}

double GradeProfile::elevation(double x) const {
    if (!std::isfinite(x))
        throw std::invalid_argument("grade query must be finite");
    const std::size_t n = knots_.size();
    std::vector<double> stations(n), grades(n), h(n);
    for (std::size_t i = 0; i < n; ++i) {
        stations[i] = knots_[i][0];
        grades[i] = knots_[i][1];
    }
    // h = [0, cumsum(diff(stations) * (g[:-1] + g[1:]) * .5)] — sequential
    // adds, matching np.cumsum's left-to-right fold.
    h[0] = 0.0;
    for (std::size_t i = 0; i + 1 < n; ++i) {
        const double ds = stations[i + 1] - stations[i];
        const double gsum = grades[i] + grades[i + 1];
        h[i + 1] = h[i] + ds * gsum * 0.5;
    }
    // index = clip(searchsorted(stations, x, 'right') - 1, 0, n - 2).
    const std::size_t idx = static_cast<std::size_t>(std::clamp(
            (std::ranges::upper_bound(stations, x) - stations.begin()) -
                    1,
            std::ptrdiff_t{0}, static_cast<std::ptrdiff_t>(n) - 2));
    const double dx = x - stations[idx];
    const double change = (grades[idx + 1] - grades[idx]) /
                          (stations[idx + 1] - stations[idx]);
    double value = h[idx] + grades[idx] * dx + 0.5 * change * dx * dx;
    if (x < 0.0) value = grades[0] * x;
    if (x > stations[n - 1])
        value = h[n - 1] + grades[n - 1] * (x - stations[n - 1]);
    return value;
}

// ---------------------------------------------------------------------------
// profile.py — TrackSpec methods
// ---------------------------------------------------------------------------

SurfaceMap TrackSpec::surface_map() const {
    return {get_surface(surface), surface_sections};
}

std::vector<std::shared_ptr<Obstacle>>
TrackSpec::sorted_obstacles() const {
    std::vector<std::shared_ptr<Obstacle>> ordered = obstacles;
    std::ranges::stable_sort(
            ordered, [](const auto &a, const auto &b) {
                return a->start_m < b->start_m;
            });
    return ordered;
}

double TrackSpec::datum_shift_m() const {
    const double grade = !grade_profile.has_value()
                                 ? 0.0
                                 : grade_profile->elevation(length_m);
    // float(sum(o.datum_shift_m for o in self.obstacles)) + grade — the
    // builtin sum() walks the UNSORTED obstacle list with a Neumaier tail.
    numeric::PythonSum sum;
    for (const auto &o : obstacles) sum.add(o->datum_shift_m());
    return sum.total() + grade;
}

std::vector<std::pair<double, std::string>> TrackSpec::markers() const {
    std::vector<std::pair<double, std::string>> out;
    for (const auto &o : sorted_obstacles())
        if (o->annotate()) out.emplace_back(o->start_m, o->label());
    return out;
}

void TrackSpec::validate() const {
    if (!std::isfinite(length_m) || length_m <= 0.0)
        throw std::invalid_argument(
                "track '" + name + "' has non-positive length " +
                detail::py_repr(length_m));
    {
        const std::vector<SurfaceSpec> registry = surfaces();
        const bool known = std::ranges::any_of(
                registry, [&](const SurfaceSpec &s) {
                    return s.name == surface;
                });
        if (!known) {
            std::string joined;
            for (const auto &s : registry) {
                if (!joined.empty()) joined += ", ";
                joined += s.name;
            }
            throw std::invalid_argument(
                    "track '" + name + "': unknown surface '" + surface +
                    "'; available: " + joined);
        }
    }
    if (grade_profile.has_value() &&
        grade_profile->knots().back()[0] > length_m)
        throw std::invalid_argument(
                "grade stations must fit inside the track");
    const SurfaceMap mapping = surface_map();
    for (const auto &s : mapping.sections())
        if (s.end_m > length_m)
            throw std::invalid_argument(
                    "material intervals must fit inside the track");
    const std::vector<std::shared_ptr<Obstacle>> ordered =
            sorted_obstacles();
    for (const auto &obs : ordered) {
        if (obs->length_m() < 0.0)
            throw std::invalid_argument(
                    "track '" + name + "': " + obs->label() +
                    " has negative length");
        if (obs->start_m < 0.0 || obs->end_m() > length_m)
            throw std::invalid_argument(
                    "track '" + name + "': " + obs->label() + " spans [" +
                    detail::py_fixed(obs->start_m, 3) + ", " +
                    detail::py_fixed(obs->end_m(), 3) +
                    "] m, outside [0, " +
                    detail::py_fixed(length_m, 3) + "] m");
    }
    for (std::size_t i = 0; i + 1 < ordered.size(); ++i) {
        const auto &prev = ordered[i];
        const auto &nxt = ordered[i + 1];
        if (nxt->start_m < prev->end_m())
            throw std::invalid_argument(
                    "track '" + name + "': " + prev->label() +
                    " ends at " + detail::py_fixed(prev->end_m(), 3) +
                    " m but " + nxt->label() + " starts at " +
                    detail::py_fixed(nxt->start_m, 3) +
                    " m -- obstacles may not overlap");
    }
}

// ---------------------------------------------------------------------------
// profile.py — build_profile / profile_extent / the plan's flat/profile
// ---------------------------------------------------------------------------

std::vector<double> build_profile(const TrackSpec &track,
                                  std::span<const double> x) {
    track.validate();
    std::vector<double> z(x.size(), 0.0);
    double datum = 0.0;

    for (const auto &obs : track.sorted_obstacles()) {
        for (std::size_t i = 0; i < x.size(); ++i)
            if (x[i] >= obs->start_m) z[i] = datum;

        const double obs_len = obs->length_m();
        const double obs_end = obs->end_m();
        if (obs_len > 0.0) {
            std::size_t count = 0;
            for (const double v : x)
                if (v >= obs->start_m && v < obs_end) ++count;
            if (count > 0) {
                std::vector<double> s_span(count), z_span(count);
                std::size_t j = 0;
                for (const double v : x)
                    if (v >= obs->start_m && v < obs_end)
                        s_span[j++] = v - obs->start_m;
                obs->elevation(s_span, z_span);
                j = 0;
                for (std::size_t i = 0; i < x.size(); ++i)
                    if (x[i] >= obs->start_m && x[i] < obs_end)
                        z[i] = datum + z_span[j++];
            }
        }

        datum += obs->datum_shift_m();
        for (std::size_t i = 0; i < x.size(); ++i)
            if (x[i] >= obs_end) z[i] = datum;
    }

    if (track.grade_profile.has_value()) {
        for (std::size_t i = 0; i < x.size(); ++i)
            z[i] += track.grade_profile->elevation(
                    detail::np_clip_scalar(x[i], 0.0, track.length_m));
    }
    return z;
}

std::array<double, 2> profile_extent(const TrackSpec &track,
                                     double resolution_m) {
    const std::vector<double> x =
            detail::np_arange(0.0, track.length_m + resolution_m,
                              resolution_m);
    const std::vector<double> z = build_profile(track, x);
    return {detail::np_min(z), detail::np_max(z)};
}

TrackSpec flat(double length_m) {
    TrackSpec track;
    track.name = "flat";
    track.length_m = length_m;
    track.validate();
    return track;
}

std::vector<std::array<double, 2>> profile(const TrackSpec &track,
                                           double resolution_m) {
    const std::vector<double> x =
            detail::np_arange(0.0, track.length_m + resolution_m,
                              resolution_m);
    const std::vector<double> z = build_profile(track, x);
    std::vector<std::array<double, 2>> out(x.size());
    for (std::size_t i = 0; i < x.size(); ++i) out[i] = {x[i], z[i]};
    return out;
}

// ---------------------------------------------------------------------------
// road.py — procedural generator. placement.py's free_intervals is owned
// by T21; generate_road's only dependency on it is this verbatim twin.
// ---------------------------------------------------------------------------

std::vector<std::array<double, 2>>
free_intervals(std::pair<double, double> span,
               std::vector<std::array<double, 2>> occupied,
               double gap_m) {
    const double lo = span.first;
    const double hi = span.second;
    std::vector<std::array<double, 2>> free;
    std::ranges::sort(occupied, [](const auto &a, const auto &b) {
        return a[0] < b[0] || (a[0] == b[0] && a[1] < b[1]);
    });
    double cursor = lo;
    for (const auto &[start, end] : occupied) {
        const double right = detail::py_min2(start - gap_m, hi);
        if (right > cursor) free.push_back({cursor, right});
        cursor = detail::py_max2(cursor, end + gap_m);
    }
    if (hi > cursor) free.push_back({cursor, hi});
    return free;
}

namespace {

[[noreturn]] void throw_no_room(double length_m, std::string_view label) {
    throw std::invalid_argument(
            "no room left for a " + detail::py_fixed(length_m, 2) + " m " +
            std::string(label) +
            ": lower the defect rates, shorten the sizes or lengthen the "
            "track");
}

// _check_weights — ordered: unknown names (sorted), empty/nonpositive
// sum (PythonSum over insertion-ordered values), negative entries.
void check_weights(std::string_view name, const WeightMap &weights,
                   std::span<const std::string_view> allowed) {
    std::vector<std::string_view> unknown;
    for (const auto &[key, w] : weights) {
        const bool known =
                std::ranges::any_of(allowed, [&](std::string_view a) {
                    return a == key;
                });
        if (!known) unknown.push_back(key);
    }
    if (!unknown.empty()) {
        std::ranges::sort(unknown);
        std::vector<std::string_view> allowed_list(allowed.begin(),
                                                   allowed.end());
        throw std::invalid_argument(
                std::string(name) + ": unknown shape(s) " +
                detail::py_str_list_repr(unknown) + "; allowed: " +
                detail::py_str_list_repr(allowed_list));
    }
    numeric::PythonSum weight_sum;
    for (const auto &[k, w] : weights) weight_sum.add(w);
    if (weights.empty() || weight_sum.total() <= 0.0)
        throw std::invalid_argument(
                std::string(name) +
                ": weights must include at least one positive entry");
    for (const auto &[k, w] : weights)
        if (w < 0.0)
            throw std::invalid_argument(
                    std::string(name) + ": weights must be non-negative");
}

// _count — int(math.floor(rate * usable / 100 + 0.5)) (round half up).
std::int64_t defect_count(double rate_per_100m, double usable_m) {
    return static_cast<std::int64_t>(
            std::floor(rate_per_100m * usable_m / 100.0 + 0.5));
}

// _draw — uniform in [lo, hi] (lo exact when hi <= lo), mm-rounded.
double draw_range(random::NumpyRng &rng, std::array<double, 2> range) {
    const double lo = range[0], hi = range[1];
    const double value = hi <= lo ? lo : rng.uniform(lo, hi);
    return detail::py_round_int(value / SIZE_ROUNDING_M) * SIZE_ROUNDING_M;
}

// _choose — sorted names, p normalized by np.sum, rng.choice(p).
std::string choose_shape(random::NumpyRng &rng, const WeightMap &weights) {
    std::vector<std::string> names;
    names.reserve(weights.size());
    for (const auto &[n, w] : weights) names.push_back(n);
    std::ranges::sort(names);
    std::vector<double> p(names.size());
    for (std::size_t i = 0; i < names.size(); ++i) {
        for (const auto &[n, w] : weights)
            if (n == names[i]) p[i] = w;
    }
    const double total = numeric::numpy_pairwise_sum(p);
    for (double &v : p) v /= total;
    const std::int64_t idx = rng.choice(std::span<const double>(p));
    return names[static_cast<std::size_t>(idx)];
}

// _place — slots, width-weighted slot choice, uniform start, cm rounding.
double place_obstacle(random::NumpyRng &rng, double length_m,
                      std::pair<double, double> span,
                      const std::vector<std::array<double, 2>> &occupied,
                      double gap_m, std::string_view label) {
    const auto free = free_intervals(span, occupied, gap_m);
    std::vector<std::array<double, 2>> slots;
    for (const auto &[a, b] : free)
        if (b - a >= length_m) slots.push_back({a, b - length_m});
    if (slots.empty()) throw_no_room(length_m, label);
    std::vector<double> widths(slots.size());
    for (std::size_t i = 0; i < slots.size(); ++i)
        widths[i] = (slots[i][1] - slots[i][0]) + POSITION_ROUNDING_M;
    const double total = numeric::numpy_pairwise_sum(widths);
    for (double &w : widths) w /= total;
    const std::size_t idx = static_cast<std::size_t>(
            rng.choice(std::span<const double>(widths)));
    const double a = slots[idx][0], b = slots[idx][1];
    const double start = b > a ? rng.uniform(a, b) : a;
    return detail::py_min2(
            detail::py_max2(
                    detail::py_round_int(start / POSITION_ROUNDING_M) *
                            POSITION_ROUNDING_M,
                    a),
            b);
}

std::shared_ptr<Obstacle> build_pothole(const std::string &edge,
                                        double start, double depth,
                                        double length, double edge_m) {
    if (edge == "sharp")
        return std::make_shared<Pothole>(start, depth, length);
    if (edge == "sloped")
        return std::make_shared<SlopedPothole>(start, depth, length,
                                               edge_m);
    return std::make_shared<BowlPothole>(start, depth, length);
}

std::shared_ptr<Obstacle> build_bump(const std::string &shape,
                                     double start, double height,
                                     double length, double ramp_fraction) {
    if (shape == "cosine")
        return std::make_shared<Bump>(start, height, length);
    const double ramp = length * ramp_fraction;
    return std::make_shared<TrapezoidBump>(start, height, ramp,
                                           length - 2.0 * ramp);
}

} // namespace

void RoadGeneratorSpec::validate() const {
    if (potholes_per_100m < 0.0 || bumps_per_100m < 0.0)
        throw std::invalid_argument("defect rates must be non-negative");
    for (const auto &[name, range] : {
                 std::pair<std::string_view, std::array<double, 2>>{
                         "pothole_depth_m", pothole_depth_m},
                 {"pothole_length_m", pothole_length_m},
                 {"bump_height_m", bump_height_m},
                 {"bump_length_m", bump_length_m}}) {
        const double lo = range[0], hi = range[1];
        if (lo < 0.0 || hi < lo)
            throw std::invalid_argument(
                    std::string(name) + " range (" +
                    detail::py_repr(lo) + ", " + detail::py_repr(hi) +
                    ") is not 0 <= low <= high");
    }
    check_weights("pothole_edge", pothole_edge, POTHOLE_EDGES);
    check_weights("bump_shape", bump_shape, BUMP_SHAPES);
    if (roughness_m < 0.0)
        throw std::invalid_argument("roughness_m must be non-negative");
    if (!(0.0 < bump_ramp_fraction && bump_ramp_fraction <= 0.5))
        throw std::invalid_argument(
                "bump_ramp_fraction must be in (0, 0.5]");
}

std::vector<std::shared_ptr<Obstacle>>
generate_road(const RoadGeneratorSpec &spec, double length_m,
              std::span<const std::array<double, 2>> reserved) {
    spec.validate();
    const std::pair<double, double> span{spec.runup_m,
                                         length_m - spec.runout_m};
    const double usable = span.second - span.first;
    if (usable <= 0.0)
        throw std::invalid_argument(
                "track of " + detail::py_repr(length_m) +
                " m leaves no room between runup " +
                detail::py_repr(spec.runup_m) + " m and runout " +
                detail::py_repr(spec.runout_m) + " m");

    random::NumpyRng rng(detail::np_seed_u64(spec.seed));
    std::vector<std::array<double, 2>> occupied(reserved.begin(),
                                                reserved.end());
    std::vector<std::shared_ptr<Obstacle>> obstacles;

    const std::int64_t n_potholes =
            defect_count(spec.potholes_per_100m, usable);
    const std::int64_t n_bumps =
            defect_count(spec.bumps_per_100m, usable);

    // Sizes and shapes draw first, potholes then bumps, in source order.
    struct Drawn {
        std::string kind;
        double size1 = 0.0;
        double size2 = 0.0;
    };
    std::vector<Drawn> potholes, bumps;
    potholes.reserve(static_cast<std::size_t>(n_potholes));
    bumps.reserve(static_cast<std::size_t>(n_bumps));
    for (std::int64_t i = 0; i < n_potholes; ++i) {
        Drawn d;
        d.kind = choose_shape(rng, spec.pothole_edge);
        d.size1 = draw_range(rng, spec.pothole_depth_m);
        d.size2 = draw_range(rng, spec.pothole_length_m);
        potholes.push_back(std::move(d));
    }
    for (std::int64_t i = 0; i < n_bumps; ++i) {
        Drawn d;
        d.kind = choose_shape(rng, spec.bump_shape);
        d.size1 = draw_range(rng, spec.bump_height_m);
        d.size2 = draw_range(rng, spec.bump_length_m);
        bumps.push_back(std::move(d));
    }

    // sorted(..., key=-length) — stable: equal lengths keep the
    // potholes-then-bumps insertion order.
    struct OrderItem {
        bool is_pothole;
        std::size_t index;
        double length;
    };
    std::vector<OrderItem> order;
    order.reserve(potholes.size() + bumps.size());
    for (std::size_t i = 0; i < potholes.size(); ++i)
        order.push_back(OrderItem{.is_pothole = true,
                                  .index = i,
                                  .length = potholes[i].size2});
    for (std::size_t i = 0; i < bumps.size(); ++i)
        order.push_back(OrderItem{.is_pothole = false,
                                  .index = i,
                                  .length = bumps[i].size2});
    std::ranges::stable_sort(order, [](const auto &a, const auto &b) {
        return a.length > b.length;
    });

    for (const auto &item : order) {
        const std::string_view label = item.is_pothole
                                               ? std::string_view("pothole")
                                               : std::string_view("bump");
        const double start =
                place_obstacle(rng, item.length, span, occupied,
                               spec.min_gap_m, label);
        std::shared_ptr<Obstacle> obstacle;
        if (item.is_pothole) {
            const Drawn &d = potholes[item.index];
            obstacle = build_pothole(d.kind, start, d.size1, d.size2,
                                     spec.pothole_edge_m);
        } else {
            const Drawn &d = bumps[item.index];
            obstacle = build_bump(d.kind, start, d.size1, d.size2,
                                  spec.bump_ramp_fraction);
        }
        occupied.push_back({obstacle->start_m, obstacle->end_m()});
        obstacles.push_back(std::move(obstacle));
    }

    if (spec.roughness_m > 0.0) {
        const double min_len = MIN_ROUGHNESS_SEGMENT_CORRELATIONS *
                               spec.roughness_correlation_m;
        for (const auto &[a, b] : free_intervals(span, occupied, 0.0)) {
            if (!(b - a >= min_len)) continue;
            double seg_len = detail::py_round_digits(b - a, 6);
            while (a + seg_len > b)
                seg_len = detail::py_round_digits(seg_len - 1e-6, 6);
            obstacles.push_back(std::make_shared<RoadRoughness>(
                    a, seg_len, spec.roughness_m,
                    spec.roughness_correlation_m,
                    rng.integers(0, 2147483647)));
        }
    }
    return obstacles;
}

// NOLINTBEGIN(bugprone-easily-swappable-parameters) (name, description, surface) mirrors road.py's signature
TrackSpec build_road(std::string_view name, const RoadGeneratorSpec &spec,
                     double length_m,
                     std::vector<std::shared_ptr<Obstacle>> hand_placed,
                     std::string_view description,
                     std::string_view surface) {
    // NOLINTEND(bugprone-easily-swappable-parameters)
    std::vector<std::array<double, 2>> reserved;
    reserved.reserve(hand_placed.size());
    for (const auto &o : hand_placed)
        reserved.push_back({o->start_m, o->end_m()});
    std::vector<std::shared_ptr<Obstacle>> generated =
            generate_road(spec, length_m, reserved);
    TrackSpec track;
    track.name = std::string(name);
    track.length_m = length_m;
    track.description = std::string(description);
    track.surface = std::string(surface);
    track.obstacles = std::move(hand_placed);
    track.obstacles.insert(track.obstacles.end(), generated.begin(),
                           generated.end());
    track.validate();
    return track;
}

RoadGeneratorSpec road_smooth_spec() {
    RoadGeneratorSpec spec;
    spec.potholes_per_100m = 1.0;
    spec.pothole_depth_m = {0.030, 0.060};
    spec.pothole_length_m = {0.300, 0.500};
    spec.bumps_per_100m = 2.0;
    spec.bump_height_m = {0.020, 0.040};
    spec.bump_length_m = {0.300, 0.500};
    spec.roughness_m = 0.002;
    return spec;
}

RoadGeneratorSpec road_worn_spec() { return RoadGeneratorSpec{}; }

RoadGeneratorSpec road_broken_spec() {
    RoadGeneratorSpec spec;
    spec.potholes_per_100m = 8.0;
    spec.pothole_depth_m = {0.060, 0.150};
    spec.pothole_length_m = {0.400, 1.000};
    spec.pothole_edge = {{"sharp", 0.6}, {"sloped", 0.3}, {"bowl", 0.1}};
    spec.bumps_per_100m = 10.0;
    spec.bump_height_m = {0.050, 0.100};
    spec.bump_length_m = {0.300, 0.700};
    spec.bump_shape = {{"cosine", 0.7}, {"trapezoid", 0.3}};
    spec.roughness_m = 0.005;
    spec.roughness_correlation_m = 0.150;
    return spec;
}

TrackSpec road_smooth() {
    return build_road("road_smooth", road_smooth_spec(),
                      DEFAULT_ROAD_LENGTH_M, {}, "Well-kept asphalt.",
                      ROAD_SURFACE);
}

TrackSpec road_worn() {
    return build_road("road_worn", road_worn_spec(),
                      DEFAULT_ROAD_LENGTH_M, {}, "Worn urban asphalt.",
                      ROAD_SURFACE);
}

TrackSpec road_broken() {
    return build_road("road_broken", road_broken_spec(),
                      DEFAULT_ROAD_LENGTH_M, {}, "Broken-up road.",
                      ROAD_SURFACE);
}

} // namespace bike::terrain
