// wheelpath.cpp — the circle-envelope wheel path (wheelpath.py). The
// sampling contract is exact: s_surface is the unique-sorted union of
// the arange grid and the four explicit edge points, and every chunk row
// takes np.max over z_surface + lift in NumPy's reduce order (identity
// -inf sequential fold for a 1-D axis reduce).
#include "profile.hpp"
#include "types.hpp"

#include <cmath>
#include <limits>

namespace bike::terrain {

// NOLINTBEGIN(bugprone-easily-swappable-parameters) (obstacle, radius, resolution) mirrors wheelpath.py
std::pair<std::vector<double>, std::vector<double>>
wheel_centre_path(const Obstacle &obstacle, double wheel_radius_m,
                  double resolution_m) {
    // NOLINTEND(bugprone-easily-swappable-parameters)
    const double r = wheel_radius_m;
    const double length = obstacle.length_m();

    std::vector<double> s_grid = detail::np_arange(
            -2.0 * r, length + 2.0 * r + resolution_m, resolution_m);
    const std::array<double, 4> s_edges = {
            -1e-9, 0.0, detail::py_max2(length - 1e-9, 0.0), length};
    s_grid.insert(s_grid.end(), s_edges.begin(), s_edges.end());
    const std::vector<double> s_surface =
            detail::np_sort_unique(std::move(s_grid));

    std::vector<double> z_surface(s_surface.size(), 0.0);
    {
        std::vector<double> inside_s;
        for (const double s : s_surface)
            if (s >= 0.0 && s < length) inside_s.push_back(s);
        if (!inside_s.empty()) {
            const std::vector<double> z_in = obstacle.elevation(inside_s);
            std::size_t j = 0;
            for (std::size_t i = 0; i < s_surface.size(); ++i)
                if (s_surface[i] >= 0.0 && s_surface[i] < length)
                    z_surface[i] = z_in[j++];
        }
    }

    const std::vector<double> x_centre = detail::np_arange(
            -r, length + r + resolution_m, resolution_m);
    std::vector<double> z_centre(x_centre.size());
    const double r2 = r * r;
    for (std::size_t i = 0; i < x_centre.size(); ++i) {
        double acc = -std::numeric_limits<double>::infinity();
        for (std::size_t j = 0; j < s_surface.size(); ++j) {
            const double dx = x_centre[i] - s_surface[j];
            const double reach = r2 - dx * dx;
            const double lift =
                    reach >= 0.0
                            ? std::sqrt(detail::np_clip_min(reach, 0.0))
                            : -std::numeric_limits<double>::infinity();
            acc = numeric::np_maximum(acc, z_surface[j] + lift);
        }
        z_centre[i] = acc;
    }
    return {x_centre, z_centre};
}

double effective_drop_m(const Obstacle &obstacle, double wheel_radius_m,
                        double resolution_m) {
    const auto &[x, z] =
            wheel_centre_path(obstacle, wheel_radius_m, resolution_m);
    double min_z = std::numeric_limits<double>::infinity();
    for (const double v : z) min_z = numeric::np_minimum(min_z, v);
    return detail::py_max2(0.0, wheel_radius_m - min_z);
}

double effective_rise_m(const Obstacle &obstacle, double wheel_radius_m,
                        double resolution_m) {
    const auto &[x, z] =
            wheel_centre_path(obstacle, wheel_radius_m, resolution_m);
    double max_z = -std::numeric_limits<double>::infinity();
    for (const double v : z) max_z = numeric::np_maximum(max_z, v);
    return detail::py_max2(0.0, max_z - wheel_radius_m);
}

// NOLINTNEXTLINE(bugprone-easily-swappable-parameters) (hole_length, wheel_radius) mirrors wheelpath.py
double bridged_drop_m(double hole_length_m, double wheel_radius_m) {
    const double half = hole_length_m / 2.0;
    if (half >= wheel_radius_m)
        return std::numeric_limits<double>::infinity();
    // wheel_radius**2 - half**2 — CPython float_pow → libm pow.
    return wheel_radius_m - std::sqrt(std::pow(wheel_radius_m, 2.0) -
                                      std::pow(half, 2.0));
}

} // namespace bike::terrain
