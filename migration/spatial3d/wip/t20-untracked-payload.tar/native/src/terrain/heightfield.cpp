// heightfield.cpp — field geometry selection, profile normalization and
// the fit gate (heightfield.py). The default-vs-derived logic is pinned:
// a track that fits the default field with the runout margin to spare
// gets the default field byte for byte; only genuine escapes resize.
#include "profile.hpp"
#include "types.hpp"

#include <cmath>

namespace bike::terrain {

std::string HeightFieldSpec::size_attr() const {
    return detail::py_fixed(radius_x_m, 6) + " " +
           detail::py_fixed(radius_y_m, 6) + " " +
           detail::py_fixed(elevation_m, 6) + " " +
           detail::py_fixed(base_m, 6);
}

std::vector<double> HeightFieldSpec::track_x() const {
    return detail::np_linspace(0.0, track_length_m(),
                               static_cast<std::size_t>(ncol));
}

std::vector<double>
HeightFieldSpec::normalize(std::span<const double> profile_m) const {
    if (std::cmp_not_equal(profile_m.size(), ncol))
        throw std::invalid_argument(
                "expected " + std::to_string(ncol) + " samples, got (" +
                std::to_string(profile_m.size()) + ",)");
    const double lo = detail::np_min(profile_m);
    const double hi = detail::np_max(profile_m);
    if (!fits({lo, hi}))
        throw std::invalid_argument(
                "profile extent [" + detail::py_fixed_signed(lo, 3) +
                ", " + detail::py_fixed_signed(hi, 3) +
                "] m leaves the field envelope [" +
                detail::py_fixed_signed(min_profile_m(), 3) + ", " +
                detail::py_fixed_signed(max_profile_m(), 3) + "] m");
    std::vector<double> data(static_cast<std::size_t>(nrow) *
                             static_cast<std::size_t>(ncol));
    for (int row = 0; row < nrow; ++row)
        for (int col = 0; col < ncol; ++col)
            data[static_cast<std::size_t>(row) *
                         static_cast<std::size_t>(ncol) +
                 static_cast<std::size_t>(col)] =
                    (profile_m[static_cast<std::size_t>(col)] +
                     datum_z_m) /
                    elevation_m;
    return data;
}

HeightFieldSpec HeightFieldSpec::with_length(double field_length_m) const {
    if (field_length_m <= 0.0)
        throw std::invalid_argument(
                "field length must be positive, got " +
                detail::py_repr(field_length_m));
    const double steps = field_length_m / resolution_m();
    if (std::fabs(steps - detail::py_round_int(steps)) > 1e-6)
        throw std::invalid_argument(
                "field length " + detail::py_repr(field_length_m) +
                " m is not a multiple of the " +
                detail::py_fixed(resolution_m() * 1000.0, 1) +
                " mm resolution");
    HeightFieldSpec out = *this;
    out.radius_x_m = field_length_m / 2.0;
    out.ncol = static_cast<int>(detail::py_round_int(steps)) + 1;
    return out;
}

HeightFieldSpec
HeightFieldSpec::for_track_length(double track_length_m_) {
    const HeightFieldSpec default_spec{};
    const double needed = track_length_m_ + FIELD_RUNOUT_MARGIN_M;
    if (needed <= default_spec.track_length_m()) return default_spec;
    const double field_length =
            std::ceil(needed / FIELD_LENGTH_STEP_M) * FIELD_LENGTH_STEP_M;
    return default_spec.with_length(field_length);
}

HeightFieldSpec HeightFieldSpec::for_track(const TrackSpec &track) {
    const HeightFieldSpec spec = for_track_length(track.length_m);
    const auto extent = profile_extent(track, spec.resolution_m());
    if (extent[0] < spec.min_profile_m() ||
        extent[1] > spec.max_profile_m()) {
        constexpr double margin_below = 1.0;
        constexpr double margin_above = 1.0;
        HeightFieldSpec out = spec;
        out.datum_z_m = detail::py_max2(
                spec.datum_z_m,
                std::ceil((-extent[0] + margin_below) * 10.0) / 10.0);
        out.elevation_m =
                std::ceil((out.datum_z_m + extent[1] + margin_above) *
                          10.0) /
                10.0;
        return out;
    }
    return spec;
}

std::vector<double>
build_field_data(const TrackSpec &track,
                 std::optional<HeightFieldSpec> spec) {
    const HeightFieldSpec field =
            spec.has_value() ? *spec : HeightFieldSpec::for_track(track);
    const std::vector<double> x = field.track_x();
    const std::vector<double> z = build_profile(track, x);
    return field.normalize(z);
}

void assert_track_fits(const TrackSpec &track,
                       const HeightFieldSpec &spec) {
    track.validate();
    if (track.length_m > spec.track_length_m())
        throw std::invalid_argument(
                "track '" + track.name + "' is " +
                detail::py_fixed(track.length_m, 1) +
                " m long, field is " +
                detail::py_fixed(spec.track_length_m(), 1) + " m");
    const auto extent = profile_extent(track, spec.resolution_m());
    if (!spec.fits(extent))
        throw std::invalid_argument(
                "track '" + track.name + "' extent [" +
                detail::py_fixed_signed(extent[0], 3) + ", " +
                detail::py_fixed_signed(extent[1], 3) +
                "] m leaves the field envelope [" +
                detail::py_fixed_signed(spec.min_profile_m(), 3) +
                ", " + detail::py_fixed_signed(spec.max_profile_m(), 3) +
                "] m");
}

} // namespace bike::terrain
