// contact_safety.cpp — single-contact rideability guards
// (contact_safety.py). The isinstance dispatch order matters:
// RockGarden first (RoadRoughness is a RockGarden), then Bump, then
// (BowlPothole, GOut); everything else is a faces hazard.
#include "profile.hpp"
#include "types.hpp"

#include <cmath>
#include <numbers>

namespace bike::terrain {

double min_bump_length_m(double height_m, double min_radius_m) {
    return std::numbers::pi *
           std::sqrt(2.0 * height_m * min_radius_m);
}

double max_bowl_depth_m(double length_m, double min_radius_m) {
    // length**2 / (2. * pi**2 * r): CPython float_pow → libm pow.
    return std::pow(length_m, 2.0) /
           (2.0 * std::pow(std::numbers::pi, 2.0) * min_radius_m);
}

double concave_span_deg(const RockGarden &obstacle, double window_m) {
    const auto [s, z] = obstacle.nodes();
    const std::size_t n = s.size();
    // mid = (s[:-1] + s[1:]) / 2; slopes = degrees(arctan(diff(z)/diff(s)))
    std::vector<double> mid(n > 0 ? n - 1 : 0), slopes(mid.size());
    for (std::size_t i = 0; i < mid.size(); ++i) {
        mid[i] = (s[i] + s[i + 1]) / 2.0;
        slopes[i] = detail::np_degrees(
                std::atan((z[i + 1] - z[i]) / (s[i + 1] - s[i])));
    }
    double worst = 0.0;
    for (std::size_t i = 0; i + 1 < slopes.size(); ++i) {
        double ahead_max = -std::numeric_limits<double>::infinity();
        bool any = false;
        for (std::size_t j = 0; j < mid.size(); ++j) {
            if (mid[j] > mid[i] && mid[j] - mid[i] <= window_m) {
                ahead_max = numeric::np_maximum(ahead_max, slopes[j]);
                any = true;
            }
        }
        if (any)
            worst = detail::py_max2(worst, ahead_max - slopes[i]);
    }
    const double entry_edge = s[0] + window_m;
    double entry_max = -std::numeric_limits<double>::infinity();
    bool any_entry = false;
    for (std::size_t i = 0; i < mid.size(); ++i) {
        if (mid[i] <= entry_edge) {
            entry_max = numeric::np_maximum(entry_max, slopes[i]);
            any_entry = true;
        }
    }
    if (any_entry) worst = detail::py_max2(worst, entry_max);
    const double exit_edge = s[n - 1] - window_m;
    double exit_min = std::numeric_limits<double>::infinity();
    bool any_exit = false;
    for (std::size_t i = 0; i < mid.size(); ++i) {
        if (mid[i] >= exit_edge) {
            exit_min = numeric::np_minimum(exit_min, slopes[i]);
            any_exit = true;
        }
    }
    if (any_exit) worst = detail::py_max2(worst, -exit_min);
    return worst;
}

// NOLINTBEGIN(bugprone-easily-swappable-parameters) (track, min_radius, max_kink, window) mirrors contact_safety.py's signature
std::vector<std::string>
single_contact_hazards(const TrackSpec &track, double min_radius_m,
                       double max_kink_deg, double window_m) {
    // NOLINTEND(bugprone-easily-swappable-parameters)
    std::vector<std::string> hazards;
    for (const auto &o : track.sorted_obstacles()) {
        const std::string label = o->label();
        if (const auto *rock = dynamic_cast<const RockGarden *>(o.get())) {
            const double span = concave_span_deg(*rock, window_m);
            if (span >= max_kink_deg)
                hazards.push_back(
                        label + ": concave span " +
                        detail::py_fixed(span, 1) + " deg >= " +
                        detail::py_g(max_kink_deg, 6) + " deg");
        } else if (const auto *bump =
                           dynamic_cast<const Bump *>(o.get())) {
            const double need =
                    min_bump_length_m(bump->height_m, min_radius_m);
            if (bump->bump_length_m < need - 1e-9)
                hazards.push_back(label + ": length " +
                                  detail::py_fixed(bump->bump_length_m,
                                                   3) +
                                  " m < " + detail::py_fixed(need, 3) +
                                  " m");
        } else if (const auto *bowl =
                           dynamic_cast<const BowlPothole *>(o.get())) {
            const double limit =
                    max_bowl_depth_m(bowl->hole_length_m, min_radius_m);
            if (bowl->depth_m > limit + 1e-9)
                hazards.push_back(label + ": depth " +
                                  detail::py_fixed(bowl->depth_m, 3) +
                                  " m > " + detail::py_fixed(limit, 3) +
                                  " m");
        } else if (const auto *gout =
                           dynamic_cast<const GOut *>(o.get())) {
            const double limit =
                    max_bowl_depth_m(gout->dip_length_m, min_radius_m);
            if (gout->depth_m > limit + 1e-9)
                hazards.push_back(label + ": depth " +
                                  detail::py_fixed(gout->depth_m, 3) +
                                  " m > " + detail::py_fixed(limit, 3) +
                                  " m");
        } else {
            hazards.push_back(label + ": " + std::string(o->class_name()) +
                              " has faces the 2D tyre cannot ride");
        }
    }
    return hazards;
}

} // namespace bike::terrain
