// obstacles.cpp — elevation formulas for the obstacle catalogue
// (obstacles.py). Every formula is written in the oracle's operation
// order: masked regions are per-element predicates, constants are the
// oracle's fl(...) products, and np.clip is the const-minmax scalar path.
// Seeded obstacles reproduce the NumpyRng draw sequence from
// bike::random::NumpyRng (T19) plus the scipy correlate1d port in
// types.hpp — the same lowering verified 0/600 bitwise earlier.
#include "types.hpp"

#include <cmath>
#include <numbers>

#include "random/numpy_compat.hpp"

namespace bike::terrain {
namespace {

constexpr double kTwoPi = 2.0 * std::numbers::pi;
constexpr double kPi = std::numbers::pi;

} // namespace

// Key functions — the vtables are emitted in this TU only.
double Obstacle::datum_shift_m() const { return 0.0; }
bool RoadRoughness::annotate() const { return false; }

void SquareEdge::elevation(std::span<const double> s,
                           std::span<double> out) const {
    for (std::size_t i = 0; i < s.size(); ++i) out[i] = height_m;
}

void Pothole::elevation(std::span<const double> s,
                        std::span<double> out) const {
    for (std::size_t i = 0; i < s.size(); ++i) out[i] = -depth_m;
}

void Washboard::elevation(std::span<const double> s,
                          std::span<double> out) const {
    // amplitude * sin(2*pi*s / wavelength)
    for (std::size_t i = 0; i < s.size(); ++i)
        out[i] = amplitude_m * std::sin(kTwoPi * s[i] / wavelength_m);
}

void GOut::elevation(std::span<const double> s,
                     std::span<double> out) const {
    // -depth * 0.5 * (1 - cos(2*pi*s / L))
    for (std::size_t i = 0; i < s.size(); ++i)
        out[i] = -depth_m * 0.5 *
                 (1.0 - std::cos(kTwoPi * s[i] / dip_length_m));
}

void Drop::elevation(std::span<const double> s,
                     std::span<double> out) const {
    if (ramp_m <= 0.0) {
        for (std::size_t i = 0; i < s.size(); ++i) out[i] = 0.0;
        return;
    }
    // -height * (s / ramp)
    for (std::size_t i = 0; i < s.size(); ++i)
        out[i] = -height_m * (s[i] / ramp_m);
}

void Kicker::elevation(std::span<const double> s,
                       std::span<double> out) const {
    const double lip = ramp_m;
    const double gap_end = ramp_m + gap_m;
    const double landing_tan =
            std::tan(detail::np_radians(landing_angle_deg));
    for (std::size_t i = 0; i < s.size(); ++i) {
        const double si = s[i];
        if (si < lip)
            out[i] = height_m * (si / ramp_m);
        else if (si >= gap_end)
            out[i] = -(si - gap_end) * landing_tan;
        else
            out[i] = 0.0;
    }
}

std::vector<double> Roots::bump_centres_m() const {
    const double margin = width_m;
    const double span_m = section_length_m - 2.0 * margin;
    const double spacing = span_m / static_cast<double>(n_bumps);
    const double clip_hi = section_length_m - margin;
    random::NumpyRng rng(detail::np_seed_u64(seed));
    // One uniform batch of n_bumps draws — the oracle's
    // rng.uniform(-j, j, size=n) * spacing elementwise.
    std::vector<double> centres(static_cast<std::size_t>(n_bumps));
    for (int i = 0; i < n_bumps; ++i) {
        const double even =
                margin +
                span_m * (static_cast<double>(i) + 0.5) /
                        static_cast<double>(n_bumps);
        const double offset =
                rng.uniform(-jitter, jitter) * spacing;
        centres[static_cast<std::size_t>(i)] =
                detail::np_clip_scalar(even + offset, margin, clip_hi);
    }
    return centres;
}

void Roots::elevation(std::span<const double> s,
                      std::span<double> out) const {
    for (std::size_t i = 0; i < s.size(); ++i) out[i] = 0.0;
    const double half = width_m / 2.0;
    const std::vector<double> centres = bump_centres_m();
    for (const double centre : centres) {
        for (std::size_t i = 0; i < s.size(); ++i) {
            const double d = std::fabs(s[i] - centre);
            if (d < half)
                out[i] += height_m * 0.5 *
                          (1.0 + std::cos(kPi * d / half));
        }
    }
}

std::pair<std::vector<double>, std::vector<double>>
RockGarden::nodes() const {
    const double spacing = correlation_length_m / 2.0;
    const std::size_t n_nodes = static_cast<std::size_t>(std::max(
            static_cast<long>(std::ceil(section_length_m / spacing)) + 1,
            4L));
    const std::vector<double> s_nodes =
            detail::np_linspace(0.0, section_length_m, n_nodes);

    random::NumpyRng rng(detail::np_seed_u64(seed));
    // rng.standard_normal(n_nodes) — one elementwise Ziggurat fill.
    std::vector<double> raw(n_nodes);
    rng.normal01(std::span<double>(raw));
    const std::vector<double> smoothed =
            detail::gaussian_filter1d_nearest(raw, 1.0);

    const double taper_len =
            detail::py_min2(correlation_length_m * 2.0,
                            section_length_m / 2.0);
    std::vector<double> shaped(n_nodes);
    for (std::size_t i = 0; i < n_nodes; ++i) {
        const double si = s_nodes[i];
        double taper = 1.0;
        if (si < taper_len)
            taper = 0.5 * (1.0 - std::cos(kPi * si / taper_len));
        else if (si > section_length_m - taper_len)
            taper = 0.5 *
                    (1.0 - std::cos(kPi * (section_length_m - si) /
                                    taper_len));
        shaped[i] = smoothed[i] * taper;
    }
    const double peak = detail::np_max_abs(shaped);
    if (peak > 0.0) {
        const double scale = amplitude_m / peak;
        for (double &v : shaped) v = v * scale;
    }
    return {s_nodes, shaped};
}

void RockGarden::elevation(std::span<const double> s,
                           std::span<double> out) const {
    const auto [s_nodes, z_nodes] = nodes();
    for (std::size_t i = 0; i < s.size(); ++i)
        out[i] = detail::np_interp(s[i], s_nodes, z_nodes);
}

void Bump::elevation(std::span<const double> s,
                     std::span<double> out) const {
    // height * 0.5 * (1 - cos(2*pi*s / L))
    for (std::size_t i = 0; i < s.size(); ++i)
        out[i] = height_m * 0.5 *
                 (1.0 - std::cos(kTwoPi * s[i] / bump_length_m));
}

void TrapezoidBump::elevation(std::span<const double> s,
                              std::span<double> out) const {
    const double fall_start = ramp_m + plateau_m;
    const double len = length_m();
    for (std::size_t i = 0; i < s.size(); ++i) {
        const double si = s[i];
        double z = height_m;
        if (ramp_m > 0.0) {
            if (si < ramp_m)
                z = height_m * (si / ramp_m);
            else if (si > fall_start)
                z = height_m * ((len - si) / ramp_m);
        }
        out[i] = detail::np_clip_scalar(z, 0.0, height_m);
    }
}

void SlopedPothole::elevation(std::span<const double> s,
                              std::span<double> out) const {
    const double edge = effective_edge_m();
    const double ascend_start = hole_length_m - edge;
    for (std::size_t i = 0; i < s.size(); ++i) {
        const double si = s[i];
        double z = -depth_m;
        if (edge > 0.0) {
            if (si < edge)
                z = -depth_m * (si / edge);
            else if (si > ascend_start)
                z = -depth_m * ((hole_length_m - si) / edge);
        }
        out[i] = detail::np_clip_scalar(z, -depth_m, 0.0);
    }
}

void BowlPothole::elevation(std::span<const double> s,
                            std::span<double> out) const {
    // -depth * 0.5 * (1 - cos(2*pi*s / L))
    for (std::size_t i = 0; i < s.size(); ++i)
        out[i] = -depth_m * 0.5 *
                 (1.0 - std::cos(kTwoPi * s[i] / hole_length_m));
}

double SteppedClimb::length_m() const {
    if (steps.empty()) return 0.0;
    // float(sum(length for _, length in steps) + len(steps)*transition)
    numeric::PythonSum sum;
    for (const auto &st : steps) sum.add(st[1]);
    return sum.total() +
           static_cast<double>(steps.size()) * transition_m;
}

double SteppedClimb::datum_shift_m() const {
    // One combined add per step: total += t*(pg+g)*0.5 + length*g.
    double total = 0.0;
    double prev_g = 0.0;
    for (const auto &st : steps) {
        const double g = st[0] / 100.0;
        total += transition_m * (prev_g + g) * 0.5 + st[1] * g;
        prev_g = g;
    }
    return total;
}

void SteppedClimb::elevation(std::span<const double> s,
                             std::span<double> out) const {
    for (std::size_t i = 0; i < s.size(); ++i) out[i] = 0.0;
    const double len = length_m();
    if (steps.empty() || !(len > 0.0)) return;

    double curr_s = 0.0;
    double curr_z = 0.0;
    double prev_g = 0.0;
    const double t_len = transition_m;

    for (const auto &st : steps) {
        const double g = st[0] / 100.0;
        const double step_len = st[1];
        // 1. Transition segment: cubic Hermite blend prev_g -> g.
        if (t_len > 0.0) {
            const double end = curr_s + t_len;
            for (std::size_t i = 0; i < s.size(); ++i) {
                if (s[i] >= curr_s && s[i] < end) {
                    const double u = s[i] - curr_s;
                    const double t = u / t_len;
                    // t**3 / t**4 are CPython float_pow → libm pow
                    // (np.power(x,2) is x*x, but ** uses pow()).
                    out[i] = curr_z +
                             t_len *
                                     (prev_g * t +
                                      (g - prev_g) *
                                              (std::pow(t, 3.0) -
                                               0.5 * std::pow(t, 4.0)));
                }
            }
            curr_s += t_len;
            curr_z += t_len * (prev_g + g) * 0.5;
        }
        // 2. Constant grade segment.
        if (step_len > 0.0) {
            const double end = curr_s + step_len;
            for (std::size_t i = 0; i < s.size(); ++i) {
                if (s[i] >= curr_s && s[i] < end)
                    out[i] = curr_z + g * (s[i] - curr_s);
            }
            curr_s += step_len;
            curr_z += g * step_len;
        }
        prev_g = g;
    }
    for (std::size_t i = 0; i < s.size(); ++i)
        if (s[i] >= len) out[i] = curr_z;
}

} // namespace bike::terrain
