// surface.cpp — the authored friction registry and the half-open
// material map (surface.py). Validation order mirrors the oracle:
// SurfaceSection checks finiteness, then 0 <= start < end, then registry
// membership; SurfaceMap sorts sections by start before the
// non-overlap check, so touching intervals pass and unordered input
// becomes ordered.
#include "profile.hpp"
#include "types.hpp"

#include <algorithm>
#include <cmath>

namespace bike::terrain {

double SurfaceSpec::mu(double sliding_speed_mps) const {
    if (!std::isfinite(sliding_speed_mps))
        throw std::invalid_argument(
                "invalid shape or non-finite "
                "SurfaceSpec.sliding_speed_mps");
    const double decay =
            std::exp(-std::fabs(sliding_speed_mps) / stribeck_speed_mps);
    return mu_slide + (mu_peak - mu_slide) * decay;
}

// ---------------------------------------------------------------------------
// The SURFACES dict in declaration order (asphalt, hardpack, loose, wet,
// scree). get_surface's KeyError maps to std::out_of_range per the
// interface contract's KeyError convention.
// ---------------------------------------------------------------------------
namespace {

const std::vector<SurfaceSpec> &registry() {
    static const std::vector<SurfaceSpec> specs = {
        SurfaceSpec("asphalt", 1.05, 0.75, 15.0,
                    DEFAULT_STRIBECK_SPEED_MPS, "dry asphalt"),
        SurfaceSpec("hardpack", 0.80, 0.60, 12.0,
                    DEFAULT_STRIBECK_SPEED_MPS, "dry hard-packed dirt"),
        SurfaceSpec("loose", 0.55, 0.45, 7.0,
                    DEFAULT_STRIBECK_SPEED_MPS,
                    "loose gravel over hardpack"),
        SurfaceSpec("wet", 0.50, 0.40, 10.0,
                    DEFAULT_STRIBECK_SPEED_MPS, "wet dirt"),
        SurfaceSpec("scree", 0.45, 0.38, 4.5,
                    DEFAULT_STRIBECK_SPEED_MPS,
                    "alpine scree: loose rock debris over bedrock"),
    };
    return specs;
}

std::string available_joined() {
    std::string joined;
    for (const auto &s : registry()) {
        if (!joined.empty()) joined += ", ";
        joined += s.name;
    }
    return joined;
}

} // namespace

const SurfaceSpec &get_surface(std::string_view name) {
    for (const auto &s : registry())
        if (s.name == name) return s;
    throw std::out_of_range("unknown surface '" + std::string(name) +
                            "'; available: " + available_joined());
}

std::vector<SurfaceSpec> surfaces() { return registry(); }

SurfaceSection::SurfaceSection(double start, double end,
                               std::string surface_name)
    : start_m(start), end_m(end), surface(std::move(surface_name)) {
    if (!std::isfinite(start_m) || !std::isfinite(end_m))
        throw std::invalid_argument(
                "surface interval stations must be finite real numbers");
    if (!(0.0 <= start_m && start_m < end_m))
        throw std::invalid_argument(
                "surface interval must satisfy 0 <= start < end");
    const bool known = std::ranges::any_of(
            registry(), [&](const SurfaceSpec &s) {
                return s.name == surface;
            });
    if (!known)
        throw std::invalid_argument("unknown surface material");
}

SurfaceMap::SurfaceMap(SurfaceSpec surface,
                       std::vector<SurfaceSection> sections)
    : surface_(std::move(surface)), sections_(std::move(sections)) {
    std::ranges::stable_sort(sections_, [](const auto &a, const auto &b) {
        return a.start_m < b.start_m;
    });
    for (std::size_t i = 0; i + 1 < sections_.size(); ++i)
        if (sections_[i + 1].start_m < sections_[i].end_m)
            throw std::invalid_argument(
                    "material intervals must not overlap");
}

SurfaceMap SurfaceMap::uniform(std::string_view name) {
    return {get_surface(name), {}};
}

const SurfaceSpec &SurfaceMap::at(double x_m) const {
    if (!std::isfinite(x_m))
        throw std::invalid_argument("invalid SurfaceMap.x_m");
    for (const auto &section : sections_)
        if (section.start_m <= x_m && x_m < section.end_m)
            return get_surface(section.surface);
    return surface_;
}

std::vector<SurfaceSpec> SurfaceMap::surfaces() const {
    // values = {base.name: base}; values.update((s.surface, get_surface))
    // — first occurrence wins the slot, later same-name updates rewrite
    // the value but keep the position.
    std::vector<SurfaceSpec> out{surface_};
    for (const auto &section : sections_) {
        const SurfaceSpec &spec = get_surface(section.surface);
        const auto it = std::ranges::find_if(
                out, [&](const SurfaceSpec &s) {
                    return s.name == spec.name;
                });
        if (it == out.end())
            out.push_back(spec);
        else
            *it = spec;
    }
    return out;
}

std::string SurfaceMap::name() const {
    return surface_.name + (sections_.empty() ? "" : "+zones");
}

void SurfaceMap::validate() const {
    double previous = 0.0;
    for (const auto &section : sections_) {
        (void)get_surface(section.surface);
        if (section.start_m < previous)
            throw std::invalid_argument(
                    "SurfaceMap.sections: unordered or overlapping "
                    "intervals");
        previous = section.end_m;
    }
}

double slip_stiffness_n(const SurfaceSpec &surface,
                        double normal_load_n) {
    if (!(normal_load_n > 0.0) || !std::isfinite(normal_load_n))
        return 0.0;
    return surface.slip_stiffness_per_load * normal_load_n;
}

} // namespace bike::terrain
