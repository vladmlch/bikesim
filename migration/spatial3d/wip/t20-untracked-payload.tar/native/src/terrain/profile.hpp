// terrain/profile.hpp — T20 function boundary for the owned terrain
// sources:
//   profile.py       build_profile / profile_extent / flat / profile
//   surface.py       get_surface / surfaces / slip_stiffness_n / registry
//   wheelpath.py     wheel_centre_path / effective_drop_m /
//                    effective_rise_m / bridged_drop_m + wheel constants
//   contact_safety.py min_bump_length_m / max_bowl_depth_m /
//                    concave_span_deg / single_contact_hazards + defaults
//   heightfield.py   build_field_data / assert_track_fits
//   road.py          generate_road / build_road / road_*_spec /
//                    road_smooth / road_worn / road_broken
//
// Tyre kernels (contact_profile.py / profile_distance.py → the
// biketyre::ProfileQuery / biketyre::SignedProfile pair) stay in
// tyre/profile.hpp; this boundary returns plain vectors/spans and never
// duplicates that machinery.
#pragma once

#include <array>
#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "types.hpp"

namespace bike::terrain {

// ---------------------------------------------------------------------------
// profile.py — assembled longitudinal profiles (profile.cpp).
// ---------------------------------------------------------------------------

// build_profile(track, x): run track.validate(), then walk obstacles in
// stable-sorted start order carrying the running datum, then add the
// clipped grade elevation. z has x.size() slots.
[[nodiscard]] std::vector<double>
build_profile(const TrackSpec &track, std::span<const double> x);

// profile_extent(track, resolution_m=0.005): (min, max) of the dense
// profile sampled over arange(0, length + resolution, resolution).
[[nodiscard]] std::array<double, 2>
profile_extent(const TrackSpec &track,
               double resolution_m = DEFAULT_RESOLUTION_M);

// flat(length_m): the plan's convenience flat-track constructor — a
// validated TrackSpec with no obstacles on the default surface.
[[nodiscard]] TrackSpec flat(double length_m);

// profile(track, resolution_m): flat/track convenience vertex builder —
// (x, z) pairs on the arange(0, L + res, res) sampling used by
// profile_extent. Kept for the plan's compile-path contract; the runtime
// field path uses HeightFieldSpec::track_x instead.
[[nodiscard]] std::vector<std::array<double, 2>>
profile(const TrackSpec &track, double resolution_m);

// ---------------------------------------------------------------------------
// surface.py — registry helpers (surface.cpp).
// ---------------------------------------------------------------------------

// get_surface(name) — SURFACES[name] or the oracle's KeyError text,
// 'unknown surface '<name>'; available: asphalt, hardpack, loose, wet,
// scree', mapped to std::out_of_range.
[[nodiscard]] const SurfaceSpec &get_surface(std::string_view name);

// Registry iteration order (dict insertion order): asphalt, hardpack,
// loose, wet, scree.
[[nodiscard]] std::vector<SurfaceSpec> surfaces();

// slip_stiffness_n(surface, normal_load_n): 0 for non-finite or
// non-positive loads, else stiffness*load (surface.py:239-248).
[[nodiscard]] double slip_stiffness_n(const SurfaceSpec &surface,
                                      double normal_load_n);

// ---------------------------------------------------------------------------
// wheelpath.py (wheelpath.cpp) — circle-envelope wheel paths.
// ---------------------------------------------------------------------------

// Front/rear reference radii used by the safety checks (wheelpath.py
// call sites and contact_safety defaults ride on these).
inline constexpr double FRONT_WHEEL_RADIUS_M = 0.372;
inline constexpr double REAR_WHEEL_RADIUS_M = 0.352;
inline constexpr double WHEELPATH_RESOLUTION_M = 0.0005;

// wheel_centre_path(obstacle, wheel_radius_m, resolution_m): (xc, zc) —
// the envelope of a circle of the given radius resting on the
// obstacle's elevation.
[[nodiscard]] std::pair<std::vector<double>, std::vector<double>>
wheel_centre_path(const Obstacle &obstacle, double wheel_radius_m,
                  double resolution_m = WHEELPATH_RESOLUTION_M);

[[nodiscard]] double effective_drop_m(
        const Obstacle &obstacle, double wheel_radius_m,
        double resolution_m = WHEELPATH_RESOLUTION_M);
[[nodiscard]] double effective_rise_m(
        const Obstacle &obstacle, double wheel_radius_m,
        double resolution_m = WHEELPATH_RESOLUTION_M);
// bridged_drop_m(gap_length_m, wheel_radius_m): drop a wheel feels over a
// sharp gap of the given length — 0 once the wheel bridges the gap.
[[nodiscard]] double bridged_drop_m(double gap_length_m,
                                    double wheel_radius_m);

// ---------------------------------------------------------------------------
// contact_safety.py (contact_safety.cpp) — single-contact rideability.
// ---------------------------------------------------------------------------

inline constexpr double SAFETY_MIN_RADIUS_M = 0.45;
inline constexpr double SAFETY_MAX_KINK_DEG = 17.0;
inline constexpr double SAFETY_WINDOW_M = 0.25;

// min_bump_length_m(height_m, min_radius_m): minimum cosine-bump length
// whose peak curvature stays under the guard radius.
[[nodiscard]] double min_bump_length_m(
        double height_m, double min_radius_m = SAFETY_MIN_RADIUS_M);
// max_bowl_depth_m(length_m, min_radius_m): maximum cosine-bowl depth
// under the guard.
[[nodiscard]] double max_bowl_depth_m(
        double length_m, double min_radius_m = SAFETY_MIN_RADIUS_M);
// concave_span_deg(rock_garden): worst concave kink over the ±window
// across the obstacle's seeded nodes.
[[nodiscard]] double concave_span_deg(const RockGarden &obstacle,
                                      double window_m = SAFETY_WINDOW_M);
// single_contact_hazards(track, *, min_radius_m, max_kink_deg,
// window_m): the oracle's hazard strings, ordered by sorted obstacle
// position.
[[nodiscard]] std::vector<std::string>
single_contact_hazards(
        const TrackSpec &track,
        double min_radius_m = SAFETY_MIN_RADIUS_M,
        double max_kink_deg = SAFETY_MAX_KINK_DEG,
        double window_m = SAFETY_WINDOW_M);

// ---------------------------------------------------------------------------
// heightfield.py (heightfield.cpp) — rasterization + fit checks.
// ---------------------------------------------------------------------------

// build_field_data(track, spec=FIELD): for_track() resize, track_x
// sampling, build_profile, normalize → nrow*ncol row-major doubles.
[[nodiscard]] std::vector<double>
build_field_data(const TrackSpec &track,
                 std::optional<HeightFieldSpec> spec = std::nullopt);

// assert_track_fits(track, spec=FIELD): profile_extent at the field's own
// resolution must fit the envelope or the oracle's ValueError fires.
void assert_track_fits(const TrackSpec &track,
                       const HeightFieldSpec &spec = FIELD);

// ---------------------------------------------------------------------------
// road.py (profile.cpp) — the procedural rough-road generator.
// ---------------------------------------------------------------------------

// free_intervals(span, occupied, gap_m) — sorted-merge free slots.
[[nodiscard]] std::vector<std::array<double, 2>>
free_intervals(std::pair<double, double> span,
               std::vector<std::array<double, 2>> occupied, double gap_m);

// generate_road(spec, length_m, reserved): the seeded obstacle layout —
// the same NumpyRng draw sequence as road.py.
[[nodiscard]] std::vector<std::shared_ptr<Obstacle>>
generate_road(const RoadGeneratorSpec &spec, double length_m,
              std::span<const std::array<double, 2>> reserved = {});

// build_road(name, spec, length_m, hand_placed, description, surface):
// reserved hand-placed spans + generated obstacles, validated.
[[nodiscard]] TrackSpec
build_road(std::string_view name, const RoadGeneratorSpec &spec,
           double length_m = DEFAULT_ROAD_LENGTH_M,
           std::vector<std::shared_ptr<Obstacle>> hand_placed = {},
           std::string_view description = "",
           std::string_view surface = ROAD_SURFACE);

[[nodiscard]] RoadGeneratorSpec road_smooth_spec();
[[nodiscard]] RoadGeneratorSpec road_worn_spec();
[[nodiscard]] RoadGeneratorSpec road_broken_spec();

[[nodiscard]] TrackSpec road_smooth();
[[nodiscard]] TrackSpec road_worn();
[[nodiscard]] TrackSpec road_broken();

} // namespace bike::terrain
