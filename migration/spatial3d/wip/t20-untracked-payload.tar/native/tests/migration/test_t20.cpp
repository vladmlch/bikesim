// test_t20.cpp — T20 terrain migration regressions. Covers the owned
// declarations behind terrain/types.hpp + terrain/profile.hpp: the 14
// obstacle elevations and seeded node grids (obstacles.py incl. the
// scipy gaussian_filter1d port), GradeProfile slope/elevation
// (grade.py), TrackSpec validation/markers/datum and build_profile /
// profile_extent over the preset layouts (profile.py), the surface
// registry + SurfaceMap half-open intervals + slip stiffness
// (surface.py), HeightFieldSpec derivation/normalize/fit and
// build_field_data (heightfield.py), the circle-envelope wheel paths
// (wheelpath.py), the single-contact hazard strings and closed-form
// guards (contact_safety.py), the generate_road draw sequence
// (road.py), the plan's flat/profile conveniences, and the reuse
// contract for the biketyre ProfileQuery/SignedProfile kernels
// (contact_profile.py / profile_distance.py — no duplicated geometry).
// Every numeric comparison is bitwise against the terrain/* manifest
// fixtures; every invalid case pins the oracle's exact message text.
#include "support/migration_test.hpp"

#include "io/json.hpp"
#include "terrain/profile.hpp"
#include "terrain/types.hpp"
#include "tyre/distance.hpp"
#include "tyre/profile.hpp"

#include <array>
#include <bit>
#include <charconv>
#include <cmath>
#include <cstdint>
#include <functional>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

namespace {

namespace terrain = bike::terrain;
namespace io = bike::io;
using io::Value;

// ---- JSON helpers (same idioms as test_t19) ---------------------------------

const Value::Object &object_of(const Value &value, std::string_view field) {
    return io::as_object(value, field);
}
const Value &member(const Value &object, std::string_view key,
                    std::string_view path) {
    const Value *found = io::find_member(object_of(object, path), key);
    bt::require(found != nullptr,
                "missing member " + std::string(path) + "." +
                        std::string(key));
    return *found;
}
const Value *member_opt(const Value &object, std::string_view key,
                        std::string_view path) {
    return io::find_member(object_of(object, path), key);
}
double number_of(const Value &value, std::string_view field) {
    const std::string lexeme = io::as_number(value, field).lexeme;
    bool ok = false;
    const double result = io::detail::float_from_lexeme(lexeme, ok);
    bt::require(ok, "number lexeme did not decode: " + lexeme);
    return result;
}
// {"$nonfinite": "nan"|"inf"|"-inf"} tagged captures decode to the IEEE
// value; ordinary numbers take the lexeme path.
double number_or_nonfinite(const Value &value, std::string_view field) {
    if (const Value::Object *o = std::get_if<Value::Object>(&value.data)) {
        if (const Value *tag = io::find_member(*o, "$nonfinite")) {
            const std::string &kind = io::as_string(*tag, field);
            if (kind == "inf")
                return std::numeric_limits<double>::infinity();
            if (kind == "-inf")
                return -std::numeric_limits<double>::infinity();
            if (kind == "nan")
                return std::numeric_limits<double>::quiet_NaN();
            bt::require(false, "unknown $nonfinite tag: " + kind);
        }
    }
    return number_of(value, field);
}
std::int64_t i64_of(const Value &value, std::string_view field) {
    return io::as_int64(value, field);
}
const std::string &string_of(const Value &value,
                             std::string_view field) {
    return io::as_string(value, field);
}
bool bool_of(const Value &value, std::string_view field) {
    return io::as_bool(value, field);
}
const Value::Array &array_of(const Value &value,
                             std::string_view field) {
    return io::as_array(value, field);
}
double num_member(const Value &object, std::string_view key,
                  std::string_view path) {
    return number_of(member(object, key, path), path);
}
std::int64_t int_member(const Value &object, std::string_view key,
                        std::string_view path) {
    return i64_of(member(object, key, path), path);
}
const std::string &str_member(const Value &object, std::string_view key,
                              std::string_view path) {
    return string_of(member(object, key, path), path);
}
std::array<double, 2> pair_member(const Value &object,
                                  std::string_view key,
                                  std::string_view path) {
    const Value::Array &a = array_of(member(object, key, path), path);
    bt::require(a.size() == 2, std::string(path) + "." +
                                 std::string(key) + " must be a pair");
    return {number_of(a[0], path), number_of(a[1], path)};
}

// NOLINTNEXTLINE(bugprone-easily-swappable-parameters) (entry, relative) is a positional helper
Value doc_of(std::string_view entry, std::string_view relative) {
    bt::manifest_verify_files(bt::manifest_entry(entry));
    return io::parse_json(
            bt::text(bt::fixture(relative)));
}

// ---- bitwise comparisons -----------------------------------------------------

void expect_bits(double expected, double actual, std::string_view label) {
    bt::require(
            std::bit_cast<std::uint64_t>(expected) ==
                    std::bit_cast<std::uint64_t>(actual),
            std::string(label) + ": bits mismatch (expected " +
                    std::to_string(expected) + ", got " +
                    std::to_string(actual) + ")");
}

// One row of an interleaved (x, z) or (x, slope, elevation) fixture.
std::vector<double> interleaved(std::span<const double> a,
                                std::span<const double> b) {
    bt::require(a.size() == b.size(), "interleave size mismatch");
    std::vector<double> out(a.size() * 2);
    for (std::size_t i = 0; i < a.size(); ++i) {
        out[2 * i] = a[i];
        out[2 * i + 1] = b[i];
    }
    return out;
}
std::vector<double> column(const std::vector<double> &rows,
                           std::size_t stride, std::size_t index) {
    std::vector<double> out(rows.size() / stride);
    for (std::size_t i = 0; i < out.size(); ++i)
        out[i] = rows[i * stride + index];
    return out;
}

void expect_msg(std::string_view expected, std::string_view py_error,
                const std::function<void()> &action,
                std::string_view label) {
    try {
        action();
    } catch (const std::out_of_range &error) {
        // Python KeyError maps to out_of_range; str(exc) adds the repr
        // quotes the fixture stores, so compare the arg text inside.
        const bool is_key_error = py_error == "KeyError";
        std::string wanted = std::string(expected);
        if (is_key_error && wanted.size() >= 2 &&
            wanted.front() == '"' && wanted.back() == '"')
            wanted = wanted.substr(1, wanted.size() - 2);
        bt::require(is_key_error && wanted == error.what(),
                    std::string(label) +
                            ": out_of_range message mismatch: '" +
                            std::string(error.what()) + "'");
        return;
    } catch (const std::invalid_argument &error) {
        bt::require(py_error != "KeyError" && expected == error.what(),
                    std::string(label) +
                            ": invalid_argument message mismatch: '" +
                            std::string(error.what()) + "'");
        return;
    }
    bt::require(false,
                std::string(label) + ": expected rejection, got none");
}

// ---- obstacle record -> concrete instance ------------------------------------

std::vector<std::array<double, 2>>
pairs_of(const Value &value, std::string_view field) {
    std::vector<std::array<double, 2>> out;
    for (const Value &v : array_of(value, field)) {
        const Value::Array &pair = array_of(v, field);
        bt::require(pair.size() == 2, "pair expected");
        out.push_back(
                {number_of(pair[0], field), number_of(pair[1], field)});
    }
    return out;
}

std::shared_ptr<terrain::Obstacle>
make_obstacle(const Value &record, std::string_view path) {
    const std::string &type = str_member(record, "type", path);
    const double start = num_member(record, "start_m", path);
    const auto num = [&](std::string_view k) {
        return num_member(record, k, path);
    };
    const auto inum = [&](std::string_view k) {
        return int_member(record, k, path);
    };
    if (type == "SquareEdge")
        return std::make_shared<terrain::SquareEdge>(
                start, num("height_m"), num("ledge_length_m"));
    if (type == "Pothole")
        return std::make_shared<terrain::Pothole>(
                start, num("depth_m"), num("hole_length_m"));
    if (type == "Washboard")
        return std::make_shared<terrain::Washboard>(
                start, num("amplitude_m"), num("wavelength_m"),
                static_cast<int>(inum("n_waves")));
    if (type == "GOut")
        return std::make_shared<terrain::GOut>(start, num("depth_m"),
                                               num("dip_length_m"));
    if (type == "Drop")
        return std::make_shared<terrain::Drop>(start, num("height_m"),
                                               num("ramp_m"));
    if (type == "Kicker")
        return std::make_shared<terrain::Kicker>(
                start, num("height_m"), num("ramp_m"), num("gap_m"),
                num("landing_angle_deg"), num("landing_m"));
    if (type == "Roots")
        return std::make_shared<terrain::Roots>(
                start, static_cast<int>(inum("n_bumps")),
                num("height_m"), num("width_m"),
                num("section_length_m"), num("jitter"), inum("seed"));
    if (type == "RockGarden")
        return std::make_shared<terrain::RockGarden>(
                start, num("section_length_m"), num("amplitude_m"),
                num("correlation_length_m"), inum("seed"));
    if (type == "Bump")
        return std::make_shared<terrain::Bump>(start, num("height_m"),
                                               num("bump_length_m"));
    if (type == "TrapezoidBump")
        return std::make_shared<terrain::TrapezoidBump>(
                start, num("height_m"), num("ramp_m"), num("plateau_m"));
    if (type == "SlopedPothole")
        return std::make_shared<terrain::SlopedPothole>(
                start, num("depth_m"), num("hole_length_m"),
                num("edge_m"));
    if (type == "BowlPothole")
        return std::make_shared<terrain::BowlPothole>(
                start, num("depth_m"), num("hole_length_m"));
    if (type == "RoadRoughness")
        return std::make_shared<terrain::RoadRoughness>(
                start, num("section_length_m"), num("amplitude_m"),
                num("correlation_length_m"), inum("seed"));
    if (type == "SteppedClimb")
        return std::make_shared<terrain::SteppedClimb>(
                start, pairs_of(member(record, "steps", path), path),
                num("transition_m"));
    bt::require(false, "unknown obstacle type: " + type);
    return nullptr;
}

void check_obstacle_fields(const terrain::Obstacle &obstacle,
                           const Value &record, std::string_view path) {
    expect_bits(num_member(record, "length_m", path),
                obstacle.length_m(), "length_m");
    expect_bits(num_member(record, "datum_shift_m", path),
                obstacle.datum_shift_m(), "datum_shift_m");
    bt::require(str_member(record, "label", path) == obstacle.label(),
                "label mismatch: " + obstacle.label());
    bt::require(bool_of(member(record, "annotate", path), path) ==
                    obstacle.annotate(),
                "annotate mismatch");
}

// ---- preset track literals (presets.py — inputs, not T21 code) ---------------

terrain::TrackSpec preset_flat() {
    terrain::TrackSpec t;
    t.name = "flat";
    t.length_m = 112.0;
    return t;
}
terrain::TrackSpec preset_single_edge() {
    terrain::TrackSpec t;
    t.name = "single_edge";
    t.length_m = 40.0;
    t.obstacles.push_back(
            std::make_shared<terrain::SquareEdge>(20.0, 0.090, 0.250));
    return t;
}
terrain::TrackSpec preset_washboard() {
    terrain::TrackSpec t;
    t.name = "washboard_only";
    t.length_m = 60.0;
    t.obstacles.push_back(std::make_shared<terrain::Washboard>(
            15.0, 0.035, 0.900, 20));
    return t;
}
terrain::TrackSpec preset_climb_steps() {
    terrain::TrackSpec t;
    t.name = "climb_steps";
    t.length_m = 115.0;
    t.surface = "hardpack";
    t.obstacles.push_back(std::make_shared<terrain::SteppedClimb>(
            15.0,
            std::vector<std::array<double, 2>>{{5.0, 15.0},
                                               {10.0, 15.0},
                                               {15.0, 15.0},
                                               {20.0, 15.0},
                                               {25.0, 15.0}},
            3.0));
    return t;
}
terrain::TrackSpec preset_enduro() {
    terrain::TrackSpec t;
    t.name = "enduro_aggressive";
    t.length_m = 115.0;
    t.obstacles = {
            std::make_shared<terrain::Washboard>(12.0, 0.035, 0.900, 9),
            std::make_shared<terrain::SquareEdge>(22.0, 0.090, 0.250),
            std::make_shared<terrain::RockGarden>(26.0, 8.0, 0.060, 0.250,
                                                  1701),
            std::make_shared<terrain::Pothole>(38.0, 0.180, 0.600),
            std::make_shared<terrain::GOut>(42.0, 0.350, 5.0),
            std::make_shared<terrain::Drop>(52.0, 0.600, 0.0),
            std::make_shared<terrain::Kicker>(57.0, 0.350, 1.400, 2.500,
                                              20.0, 5.000),
            std::make_shared<terrain::Roots>(69.0, 7, 0.080, 0.250, 7.0,
                                             0.35, 2029),
            std::make_shared<terrain::SquareEdge>(80.0, 0.070, 0.250),
            std::make_shared<terrain::SquareEdge>(80.8, 0.090, 0.250),
            std::make_shared<terrain::RockGarden>(84.0, 11.0, 0.090,
                                                  0.200, 3301),
    };
    return t;
}

terrain::TrackSpec preset_track(std::string_view name) {
    if (name == "flat") return preset_flat();
    if (name == "single_edge") return preset_single_edge();
    if (name == "washboard_only") return preset_washboard();
    if (name == "climb_steps") return preset_climb_steps();
    if (name == "enduro_aggressive") return preset_enduro();
    if (name == "road_smooth") return terrain::road_smooth();
    if (name == "road_worn") return terrain::road_worn();
    if (name == "road_broken") return terrain::road_broken();
    bt::require(false, "unknown preset");
    return {};
}

// ---- obstacle elevations ------------------------------------------------------

void test_obstacle_elevations() {
    const std::string entry = "terrain/obstacle-elevations";
    const Value doc = doc_of(entry, "terrain/obstacle_elevations.json");
    for (const Value &c : array_of(member(doc, "cases", "doc"), "doc")) {
        const std::string &name = str_member(c, "name", "case");
        const Value &record = member(c, "record", "case");
        const std::shared_ptr<terrain::Obstacle> obstacle =
                make_obstacle(record, name);
        check_obstacle_fields(*obstacle, record, name);
        const Value &grid = member(record, "grid", name);
        const std::vector<double> s = terrain::detail::np_arange(
                number_of(member(grid, "start", name), name),
                number_of(member(grid, "stop", name), name),
                number_of(member(grid, "step", name), name));
        bt::require(static_cast<std::int64_t>(s.size()) ==
                            int_member(grid, "count", name),
                    name + ": grid size mismatch");
        const std::vector<double> elev = obstacle->elevation(s);
        bt::golden_f64("terrain/obstacle_" + name + ".f64",
                       interleaved(s, elev));
    }
}

// ---- seeded node grids ---------------------------------------------------------

void test_rock_nodes() {
    bt::manifest_verify_files(
            bt::manifest_entry("terrain/rock-garden-nodes"));
    struct Case {
        const char *tag;
        double section, amp, corr;
        std::int64_t seed;
    };
    const std::array cases{
            Case{.tag = "seed1701", .section = 8.0, .amp = 0.060,
                 .corr = 0.250, .seed = 1701},
            Case{.tag = "seed3301", .section = 11.0, .amp = 0.090,
                 .corr = 0.200, .seed = 3301},
            Case{.tag = "seed0", .section = 8.0, .amp = 0.060,
                 .corr = 0.250, .seed = 0},
            Case{.tag = "rough17", .section = 10.0, .amp = 0.003,
                 .corr = 0.200, .seed = 17},
    };
    for (const auto &c : cases) {
        const terrain::RockGarden garden(0.0, c.section, c.amp, c.corr,
                                         c.seed);
        const auto [s, z] = garden.nodes();
        bt::golden_f64(std::string("terrain/rock_nodes_") + c.tag +
                               ".f64",
                       interleaved(s, z));
    }
    const terrain::Roots roots(69.0, 7, 0.08, 0.25, 7.0, 0.35, 2029);
    bt::golden_f64("terrain/roots_centres_2029.f64",
                   roots.bump_centres_m());
}

// ---- track fields + dense profiles ---------------------------------------------

void test_track_fields() {
    const std::string entry = "terrain/track-fields";
    const Value doc = doc_of(entry, "terrain/track_fields.json");
    for (const Value &t :
         array_of(member(doc, "tracks", "doc"), "doc")) {
        const std::string &name = str_member(t, "name", "track");
        const terrain::TrackSpec track = preset_track(name);
        expect_bits(num_member(t, "length_m", name), track.length_m,
                    name + ": length_m");
        expect_bits(num_member(t, "datum_shift_m", name),
                    track.datum_shift_m(), name + ": datum_shift_m");
        const auto extent = pair_member(t, "extent", name);
        const auto actual_extent = terrain::profile_extent(track);
        expect_bits(extent[0], actual_extent[0],
                    name + ": extent lo");
        expect_bits(extent[1], actual_extent[1],
                    name + ": extent hi");
        bt::require(str_member(t, "surface_map", name) ==
                            track.surface_map().name(),
                    name + ": surface_map name");
        const Value::Array &markers =
                array_of(member(t, "markers", name), name);
        const auto actual_markers = track.markers();
        bt::require(markers.size() == actual_markers.size(),
                    name + ": marker count");
        for (std::size_t i = 0; i < markers.size(); ++i) {
            const Value::Array &pair = array_of(markers[i], name);
            expect_bits(number_of(pair[0], name),
                        actual_markers[i].first,
                        name + ": marker x");
            bt::require(string_of(pair[1], name) ==
                            actual_markers[i].second,
                        name + ": marker label");
        }
        // Dense profile: x = arange(0, L + res/2, res), z = build_profile.
        const std::vector<double> x = terrain::detail::np_arange(
                0.0, track.length_m + 0.0025, 0.005);
        const std::vector<double> z = terrain::build_profile(track, x);
        bt::golden_f64("terrain/" + name + "_profile_dense.f64",
                       interleaved(x, z));
    }
}

// ---- generate_road layouts -------------------------------------------------------

terrain::WeightMap weight_map(const Value &object, std::string_view key,
                              std::string_view path) {
    terrain::WeightMap out;
    for (const auto &[k, v] : object_of(member(object, key, path), path))
        out.emplace_back(k, number_of(v, path));
    return out;
}

terrain::RoadGeneratorSpec road_spec_of(const Value &object,
                                        std::string_view path) {
    terrain::RoadGeneratorSpec spec;
    spec.seed = int_member(object, "seed", path);
    spec.runup_m = num_member(object, "runup_m", path);
    spec.runout_m = num_member(object, "runout_m", path);
    spec.min_gap_m = num_member(object, "min_gap_m", path);
    spec.potholes_per_100m =
            num_member(object, "potholes_per_100m", path);
    spec.pothole_depth_m =
            pair_member(object, "pothole_depth_m", path);
    spec.pothole_length_m =
            pair_member(object, "pothole_length_m", path);
    spec.pothole_edge = weight_map(object, "pothole_edge", path);
    spec.pothole_edge_m = num_member(object, "pothole_edge_m", path);
    spec.bumps_per_100m = num_member(object, "bumps_per_100m", path);
    spec.bump_height_m = pair_member(object, "bump_height_m", path);
    spec.bump_length_m = pair_member(object, "bump_length_m", path);
    spec.bump_shape = weight_map(object, "bump_shape", path);
    spec.bump_ramp_fraction =
            num_member(object, "bump_ramp_fraction", path);
    spec.roughness_m = num_member(object, "roughness_m", path);
    spec.roughness_correlation_m =
            num_member(object, "roughness_correlation_m", path);
    return spec;
}

void check_obstacle_record(const terrain::Obstacle &obstacle,
                           const Value &record, std::string_view path) {
    bt::require(str_member(record, "type", path) ==
                    obstacle.class_name(),
                std::string(path) + ": type mismatch " +
                        std::string(obstacle.class_name()));
    expect_bits(num_member(record, "start_m", path), obstacle.start_m,
                std::string(path) + ": start_m");
    const std::string &type = str_member(record, "type", path);
    const auto expect = [&](std::string_view field, double actual) {
        expect_bits(num_member(record, field, path), actual,
                    std::string(path) + ": " + std::string(field));
    };
    if (type == "Pothole") {
        const auto &o = dynamic_cast<const terrain::Pothole &>(obstacle);
        expect("depth_m", o.depth_m);
        expect("hole_length_m", o.hole_length_m);
    } else if (type == "SlopedPothole") {
        const auto &o =
                dynamic_cast<const terrain::SlopedPothole &>(obstacle);
        expect("depth_m", o.depth_m);
        expect("hole_length_m", o.hole_length_m);
        expect("edge_m", o.edge_m);
    } else if (type == "BowlPothole") {
        const auto &o =
                dynamic_cast<const terrain::BowlPothole &>(obstacle);
        expect("depth_m", o.depth_m);
        expect("hole_length_m", o.hole_length_m);
    } else if (type == "Bump") {
        const auto &o = dynamic_cast<const terrain::Bump &>(obstacle);
        expect("height_m", o.height_m);
        expect("bump_length_m", o.bump_length_m);
    } else if (type == "TrapezoidBump") {
        const auto &o =
                dynamic_cast<const terrain::TrapezoidBump &>(obstacle);
        expect("height_m", o.height_m);
        expect("ramp_m", o.ramp_m);
        expect("plateau_m", o.plateau_m);
    } else if (type == "RoadRoughness") {
        const auto &o =
                dynamic_cast<const terrain::RoadRoughness &>(obstacle);
        expect("section_length_m", o.section_length_m);
        expect("amplitude_m", o.amplitude_m);
        expect("correlation_length_m", o.correlation_length_m);
        bt::require(int_member(record, "seed", path) == o.seed,
                    std::string(path) + ": seed");
    } else {
        bt::require(false, std::string(path) + ": unexpected generated type " + type);
    }
}

void test_road_obstacles() {
    const Value doc = doc_of("terrain/road-obstacles",
                             "terrain/road_obstacles.json");
    for (const Value &road : array_of(member(doc, "roads", "doc"), "doc")) {
        const std::string &name = str_member(road, "name", "road");
        const double length = num_member(road, "length_m", name);
        const terrain::RoadGeneratorSpec spec =
                road_spec_of(member(road, "spec", name), name);
        std::vector<std::array<double, 2>> reserved;
        for (const Value &r :
             array_of(member(road, "reserved", name), name)) {
            const Value::Array &pair = array_of(r, name);
            reserved.push_back({number_of(pair[0], name),
                                number_of(pair[1], name)});
        }
        const std::vector<std::shared_ptr<terrain::Obstacle>> generated =
                terrain::generate_road(spec, length, reserved);
        const Value::Array &records =
                array_of(member(road, "obstacles", name), name);
        bt::require(generated.size() == records.size(),
                    name + ": obstacle count " +
                            std::to_string(generated.size()) + " vs " +
                            std::to_string(records.size()));
        for (std::size_t i = 0; i < generated.size(); ++i)
            check_obstacle_record(*generated[i], records[i],
                                  name + "[" + std::to_string(i) + "]");
    }
}

// ---- grade ----------------------------------------------------------------------

void test_grade() {
    bt::manifest_verify_files(bt::manifest_entry("terrain/grade"));
    const std::vector<double> rows =
            bt::read_f64(bt::fixture("terrain/grade.f64"));
    bt::require(rows.size() % 3 == 0, "grade.f64 must carry triples");
    const terrain::GradeProfile grade(
            {{0.0, 0.0}, {10.0, 0.0}, {12.0, 0.177}, {120.0, 0.0}});
    const std::vector<double> x = column(rows, 3, 0);
    std::vector<double> actual;
    actual.reserve(rows.size());
    for (const double xi : x) {
        actual.push_back(xi);
        actual.push_back(grade.slope(xi));
        actual.push_back(grade.elevation(xi));
    }
    bt::golden_f64("terrain/grade.f64", actual);
}

// ---- surfaces --------------------------------------------------------------------

void test_surface() {
    const Value doc = doc_of("terrain/surface", "terrain/surface.json");
    const std::vector<double> speeds =
            [&] {
                std::vector<double> out;
                for (const Value &v :
                     array_of(member(doc, "speeds", "doc"), "doc"))
                    out.push_back(number_of(v, "speeds"));
                return out;
            }();
    const std::vector<double> loads =
            [&] {
                std::vector<double> out;
                for (const Value &v :
                     array_of(member(doc, "loads", "doc"), "doc"))
                    out.push_back(number_of(v, "loads"));
                return out;
            }();
    for (const auto &[sname, spec_v] :
         object_of(member(doc, "specs", "doc"), "specs")) {
        const terrain::SurfaceSpec &spec = terrain::get_surface(sname);
        const Value &sv = spec_v;
        expect_bits(num_member(sv, "mu_peak", sname), spec.mu_peak,
                    sname + ": mu_peak");
        expect_bits(num_member(sv, "mu_slide", sname), spec.mu_slide,
                    sname + ": mu_slide");
        expect_bits(num_member(sv, "slip_stiffness_per_load", sname),
                    spec.slip_stiffness_per_load,
                    sname + ": slip_stiffness_per_load");
        expect_bits(num_member(sv, "stribeck_speed_mps", sname),
                    spec.stribeck_speed_mps,
                    sname + ": stribeck_speed_mps");
        bt::require(str_member(sv, "description", sname) ==
                        spec.description,
                    sname + ": description");
        const Value::Array &mu_row = array_of(
                member(member(doc, "mu", "doc"), sname, "mu"), "mu");
        for (std::size_t i = 0; i < speeds.size(); ++i)
            expect_bits(number_of(mu_row[i], "mu"),
                        spec.mu(speeds[i]),
                        sname + ": mu(" + std::to_string(speeds[i]) +
                                ")");
        const Value::Array &slip_row = array_of(
                member(member(doc, "slip", "doc"), sname, "slip"),
                "slip");
        for (std::size_t i = 0; i < loads.size(); ++i)
            expect_bits(number_of(slip_row[i], "slip"),
                        terrain::slip_stiffness_n(spec, loads[i]),
                        sname + ": slip(" + std::to_string(loads[i]) +
                                ")");
    }
    const Value &map_v =
            member(member(doc, "maps", "doc"), "hardpack_wet_loose",
                   "maps");
    const terrain::SurfaceMap map(
            terrain::get_surface("hardpack"),
            {terrain::SurfaceSection(5.0, 10.0, "wet"),
             terrain::SurfaceSection(30.0, 40.0, "loose")});
    bt::require(str_member(map_v, "name", "map") == map.name(),
                "map name");
    const Value::Array &expected_surfaces =
            array_of(member(map_v, "surfaces", "map"), "map");
    const std::vector<terrain::SurfaceSpec> actual_surfaces =
            map.surfaces();
    bt::require(expected_surfaces.size() == actual_surfaces.size(),
                "map surfaces count");
    for (std::size_t i = 0; i < actual_surfaces.size(); ++i)
        bt::require(string_of(expected_surfaces[i], "map") ==
                        actual_surfaces[i].name,
                    "map surfaces[" + std::to_string(i) + "]");
    const Value::Array &probe_x =
            array_of(member(map_v, "probe_x", "map"), "map");
    for (const Value &px : probe_x) {
        const double x = number_of(px, "probe");
        const std::string key = [&] {
            if (x == static_cast<double>(static_cast<long long>(x)) &&
                !std::signbit(x))
                return std::to_string(static_cast<long long>(x)) + ".0";
            // repr() of the probe values the capture recorded.
            std::array<char, 64> buf{};
            const auto out =
                    std::to_chars(buf.data(), std::to_address(buf.end()), x);
            return std::string(buf.data(), out.ptr);
        }();
        const std::string &expected_name = str_member(
                member(map_v, "probes", "map"), key, "probes");
        bt::require(map.at(x).name == expected_name,
                    "map.at(" + key + ") -> " + map.at(x).name);
    }
}

// ---- heightfield -------------------------------------------------------------------

void test_heightfield() {
    const Value doc =
            doc_of("terrain/heightfield", "terrain/heightfield.json");
    struct TrackCase {
        const char *name = nullptr;
        terrain::TrackSpec track;
    };
    const std::array tracks{
            TrackCase{.name = "for_flat112", .track = preset_flat()},
            TrackCase{.name = "for_long200", .track = [] {
                           terrain::TrackSpec t;
                           t.name = "long";
                           t.length_m = 200.0;
                           return t;
                       }()},
            TrackCase{.name = "for_grade40", .track = [] {
                           terrain::TrackSpec t;
                           t.name = "gradey";
                           t.length_m = 40.0;
                           t.grade_profile = terrain::GradeProfile(
                                   {{0.0, 0.0}, {40.0, 0.3}});
                           return t;
                       }()},
            TrackCase{.name = "for_deep60", .track = [] {
                           terrain::TrackSpec t;
                           t.name = "deep";
                           t.length_m = 60.0;
                           t.obstacles = {
                                   std::make_shared<terrain::Pothole>(
                                           10.0, 3.5, 2.0),
                                   std::make_shared<terrain::SquareEdge>(
                                           30.0, 1.2, 1.0),
                           };
                           return t;
                       }()},
            TrackCase{.name = "for_enduro", .track = preset_enduro()},
    };
    const auto check_spec = [&](std::string_view name,
                                const terrain::HeightFieldSpec &spec) {
        const Value &sv = member(member(doc, "specs", "doc"), name, "specs");
        bt::require(int_member(sv, "nrow", name) == spec.nrow,
                    std::string(name) + ": nrow");
        bt::require(int_member(sv, "ncol", name) == spec.ncol,
                    std::string(name) + ": ncol");
        expect_bits(num_member(sv, "radius_x_m", name), spec.radius_x_m,
                    std::string(name) + ": radius_x_m");
        expect_bits(num_member(sv, "radius_y_m", name), spec.radius_y_m,
                    std::string(name) + ": radius_y_m");
        expect_bits(num_member(sv, "elevation_m", name),
                    spec.elevation_m, std::string(name) + ": elevation");
        expect_bits(num_member(sv, "base_m", name), spec.base_m,
                    std::string(name) + ": base_m");
        expect_bits(num_member(sv, "datum_z_m", name), spec.datum_z_m,
                    std::string(name) + ": datum_z");
        expect_bits(num_member(sv, "track_length_m", name),
                    spec.track_length_m(), std::string(name) + ": track_length");
        expect_bits(num_member(sv, "resolution_m", name),
                    spec.resolution_m(), std::string(name) + ": resolution");
        expect_bits(num_member(sv, "min_profile_m", name),
                    spec.min_profile_m(), std::string(name) + ": min");
        expect_bits(num_member(sv, "max_profile_m", name),
                    spec.max_profile_m(), std::string(name) + ": max");
        bt::require(str_member(sv, "size_attr", name) ==
                        spec.size_attr(),
                    std::string(name) + ": size_attr");
        bt::require(bool_of(member(sv, "is_default", name), name) ==
                        spec.is_default(),
                    std::string(name) + ": is_default");
        const Value &geom =
                member(member(doc, "geom", "doc"), name, "geom");
        expect_bits(num_member(geom, "geom_x_m", name),
                    spec.geom_x_m(), std::string(name) + ": geom_x");
        expect_bits(num_member(geom, "geom_z_m", name),
                    spec.geom_z_m(0.5), std::string(name) + ": geom_z");
        expect_bits(num_member(geom, "catch_plane_z_m", name),
                    spec.catch_plane_z_m(0.5),
                    std::string(name) + ": catch_plane");
    };
    check_spec("default", terrain::FIELD);
    for (const auto &t : tracks)
        check_spec(t.name, terrain::HeightFieldSpec::for_track(t.track));
    // with_length(130.0) record.
    {
        const Value &wl = member(doc, "with_length_130", "doc");
        const terrain::HeightFieldSpec stretched =
                terrain::FIELD.with_length(130.0);
        expect_bits(num_member(wl, "radius_x_m", "wl"),
                    stretched.radius_x_m, "wl radius_x");
        bt::require(int_member(wl, "ncol", "wl") == stretched.ncol,
                    "wl ncol");
    }
    // build_field_data + the default track_x.
    bt::golden_f64("terrain/track_x_default.f64",
                   terrain::FIELD.track_x());
    bt::golden_f64("terrain/field_data_flat.f64",
                   terrain::build_field_data(preset_flat()));
    bt::golden_f64("terrain/field_data_enduro.f64",
                   terrain::build_field_data(preset_enduro()));
    {
        terrain::TrackSpec t;
        t.name = "long";
        t.length_m = 200.0;
        bt::golden_f64("terrain/field_data_long.f64",
                       terrain::build_field_data(t));
    }
}

// ---- wheelpath -----------------------------------------------------------------------

void test_wheelpath() {
    const Value doc =
            doc_of("terrain/wheelpath", "terrain/wheelpath.json");
    struct PathCase {
        const char *name = nullptr;
        std::shared_ptr<terrain::Obstacle> obstacle;
    };
    const std::array cases{
            PathCase{.name = "pothole",
                     .obstacle = std::make_shared<terrain::Pothole>(
                             0.0, 0.180, 0.600)},
            PathCase{.name = "bump",
                     .obstacle = std::make_shared<terrain::Bump>(
                             0.0, 0.050, 0.400)},
            PathCase{.name = "rock1701",
                     .obstacle = std::make_shared<terrain::RockGarden>(
                             0.0, 8.0, 0.060, 0.250, 1701)},
            PathCase{.name = "drop_ramp",
                     .obstacle = std::make_shared<terrain::Drop>(
                             0.0, 0.600, 0.75)},
            PathCase{.name = "kicker",
                     .obstacle = std::make_shared<terrain::Kicker>(
                             0.0, 0.350, 1.400, 2.500, 20.0, 5.000)},
    };
    for (const auto &c : cases) {
        const auto [xc, zc] =
                terrain::wheel_centre_path(*c.obstacle, 0.372);
        bt::golden_f64(std::string("terrain/wheelpath_") + c.name +
                               ".f64",
                       interleaved(xc, zc));
        const Value &scalars =
                member(member(doc, "scalars", "doc"), c.name, "scalars");
        expect_bits(num_member(scalars, "drop", c.name),
                    terrain::effective_drop_m(*c.obstacle, 0.372),
                    std::string(c.name) + ": drop");
        expect_bits(num_member(scalars, "rise", c.name),
                    terrain::effective_rise_m(*c.obstacle, 0.372),
                    std::string(c.name) + ": rise");
        bt::require(int_member(scalars, "n", c.name) ==
                            static_cast<std::int64_t>(xc.size()),
                    std::string(c.name) + ": path size");
    }
    const Value &bridged = member(doc, "bridged", "doc");
    for (const auto &[key, expected] : object_of(bridged, "bridged")) {
        double width = 0.0;
        const auto parsed = std::from_chars(
                key.data(), std::to_address(key.cend()), width);
        bt::require(parsed.ec == std::errc() &&
                        parsed.ptr == std::to_address(key.cend()),
                    "bridged key must decode");
        expect_bits(number_or_nonfinite(expected, key),
                    terrain::bridged_drop_m(width, 0.372),
                    "bridged(" + key + ")");
    }
}

// ---- contact safety -------------------------------------------------------------------

void test_contact_safety() {
    const Value doc = doc_of("terrain/contact-safety",
                             "terrain/contact_safety.json");
    const Value &hazards = member(doc, "hazards", "doc");
    {
        const Value::Array &expected =
                array_of(member(hazards, "enduro_aggressive", "h"), "h");
        const std::vector<std::string> actual =
                terrain::single_contact_hazards(preset_enduro());
        bt::require(expected.size() == actual.size(),
                    "enduro hazard count");
        for (std::size_t i = 0; i < actual.size(); ++i)
            bt::require(string_of(expected[i], "h") == actual[i],
                        "enduro hazard[" + std::to_string(i) + "]");
    }
    {
        terrain::TrackSpec hazard_track;
        hazard_track.name = "hazards";
        hazard_track.length_m = 120.0;
        hazard_track.obstacles = {
                std::make_shared<terrain::Bump>(5.0, 0.05, 0.4),
                std::make_shared<terrain::BowlPothole>(10.0, 0.15, 0.5),
                std::make_shared<terrain::GOut>(20.0, 0.5, 1.0),
                std::make_shared<terrain::SquareEdge>(30.0),
                std::make_shared<terrain::RoadRoughness>(40.0, 10.0,
                                                         0.003, 0.2,
                                                         17),
                std::make_shared<terrain::Kicker>(55.0, 0.350, 1.400,
                                                  2.500, 20.0, 5.000),
                std::make_shared<terrain::Roots>(65.0, 7, 0.080, 0.250,
                                                 7.0, 0.35, 2029),
                std::make_shared<terrain::TrapezoidBump>(75.0),
                std::make_shared<terrain::SlopedPothole>(80.0),
                std::make_shared<terrain::Pothole>(85.0),
                std::make_shared<terrain::Washboard>(90.0),
                std::make_shared<terrain::Drop>(100.0),
                std::make_shared<terrain::SteppedClimb>(
                        105.0, std::vector<std::array<double, 2>>{
                                       {5.0, 4.0}},
                        1.0),
        };
        const Value::Array &expected =
                array_of(member(hazards, "custom", "h"), "h");
        const std::vector<std::string> actual =
                terrain::single_contact_hazards(hazard_track);
        bt::require(expected.size() == actual.size(),
                    "custom hazard count " +
                            std::to_string(actual.size()));
        for (std::size_t i = 0; i < actual.size(); ++i)
            bt::require(string_of(expected[i], "h") == actual[i],
                        "custom hazard[" + std::to_string(i) + "] '" +
                                actual[i] + "'");
    }
    const Value &guards = member(doc, "guards", "doc");
    expect_bits(num_member(guards, "min_bump_length_0.05", "g"),
                terrain::min_bump_length_m(0.05), "min_bump 0.05");
    expect_bits(num_member(guards, "min_bump_length_0.09", "g"),
                terrain::min_bump_length_m(0.09), "min_bump 0.09");
    expect_bits(num_member(guards, "max_bowl_depth_0.5", "g"),
                terrain::max_bowl_depth_m(0.5), "max_bowl 0.5");
    expect_bits(num_member(guards, "max_bowl_depth_5.0", "g"),
                terrain::max_bowl_depth_m(5.0), "max_bowl 5.0");
    const Value &concave = member(doc, "concave", "doc");
    expect_bits(num_member(concave, "rock1701", "c"),
                terrain::concave_span_deg(
                        terrain::RockGarden(26.0, 8.0, 0.060, 0.250,
                                            1701)),
                "concave 1701");
    expect_bits(num_member(concave, "rock3301", "c"),
                terrain::concave_span_deg(
                        terrain::RockGarden(84.0, 11.0, 0.090, 0.200,
                                            3301)),
                "concave 3301");
    expect_bits(num_member(concave, "road_roughness17", "c"),
                terrain::concave_span_deg(
                        terrain::RoadRoughness(40.0, 10.0, 0.003, 0.200,
                                               17)),
                "concave rough17");
}

// ---- reuse: biketyre ProfileQuery + SignedProfile ------------------------------------

void test_profile_kernels() {
    const Value doc = doc_of("terrain/profile-kernels",
                             "terrain/profile_kernels.json");
    const std::vector<std::array<double, 2>> verts =
            pairs_of(member(doc, "vertices", "doc"), "doc");
    const biketyre::SignedProfile signed_profile(verts);
    std::vector<double> px, pz;
    for (const auto &v : verts) {
        px.push_back(v[0]);
        pz.push_back(v[1]);
    }
    const biketyre::ProfileQuery query(px, pz, 0.0001, 0.05, 20.0);
    for (const Value &row :
         array_of(member(doc, "distance", "doc"), "doc")) {
        const auto p = pair_member(row, "point", "row");
        const biketyre::PointDistance d = signed_profile.query(p);
        expect_bits(num_member(row, "distance", "row"), d.distance,
                    "distance");
        const auto n = pair_member(row, "normal", "row");
        expect_bits(n[0], d.normal[0], "normal.x");
        expect_bits(n[1], d.normal[1], "normal.z");
        const auto c = pair_member(row, "closest", "row");
        expect_bits(c[0], d.point[0], "closest.x");
        expect_bits(c[1], d.point[1], "closest.z");
        bt::require(int_member(row, "segment", "row") == d.segment,
                    "segment id");
        bt::require(bool_of(member(row, "nonsmooth", "row"), "row") ==
                        d.nonsmooth,
                    "nonsmooth");
    }
    for (const Value &row :
         array_of(member(doc, "height", "doc"), "doc")) {
        expect_bits(num_member(row, "z", "row"),
                    signed_profile.height(num_member(row, "x", "row")),
                    "height");
    }
    for (const Value &row :
         array_of(member(doc, "contact", "doc"), "doc")) {
        const auto c = pair_member(row, "center", "row");
        const double radius = num_member(row, "radius", "row");
        std::optional<int> previous;
        if (const Value *prev = member_opt(row, "previous", "row");
            prev != nullptr && !std::holds_alternative<std::monostate>(
                                       prev->data))
            previous = static_cast<int>(
                    i64_of(*prev, "row"));
        const biketyre::ProfileContact contact =
                query.contact(c, radius, previous);
        const auto p = pair_member(row, "point", "row");
        expect_bits(p[0], contact.point[0], "contact point.x");
        expect_bits(p[1], contact.point[1], "contact point.z");
        const auto n = pair_member(row, "normal", "row");
        expect_bits(n[0], contact.normal[0], "contact normal.x");
        expect_bits(n[1], contact.normal[1], "contact normal.z");
        expect_bits(num_member(row, "delta", "row"), contact.delta,
                    "delta");
        bt::require(int_member(row, "segment_id", "row") ==
                        contact.segment_id,
                    "segment_id");
        bt::require(
                bool_of(member(row, "multi_support", "row"), "row") ==
                        contact.multi_support,
                "multi_support");
    }
}

// ---- convenience constructors (the plan's flat/profile contract) ---------------------

void test_convenience() {
    const terrain::TrackSpec flat = terrain::flat(10.0);
    bt::require(flat.length_m == 10.0 && flat.obstacles.empty(),
                "flat() must produce a validated featureless track");
    const std::vector<std::array<double, 2>> profile =
            terrain::profile(flat, 0.1);
    bt::require(profile.size() >= 2, "profile() needs >= 2 vertices");
    for (const auto &v : profile)
        bt::require(v[1] == 0.0, "flat profile must stay at the datum");
    const auto extent = terrain::profile_extent(flat);
    bt::require(extent[0] == 0.0 && extent[1] == 0.0,
                "flat extent must be zero");
}

// ---- validation: exact error kinds + message text -------------------------------------

void test_validation() {
    const Value doc =
            doc_of("terrain/validation", "terrain/validation.json");
    const std::map<std::string, std::function<void()>> actions = [] {
        std::map<std::string, std::function<void()>> a;
        const auto track = [](std::string name, double length,
                              std::vector<
                                      std::shared_ptr<terrain::Obstacle>>
                                      obstacles = {},
                              std::string surface = "hardpack") {
            terrain::TrackSpec t;
            t.name = std::move(name);
            t.length_m = length;
            t.obstacles = std::move(obstacles);
            t.surface = std::move(surface);
            return t;
        };
        a["track_zero_length"] = [track] {
            track("t", 0.0).validate();
        };
        a["track_negative_length"] = [track] {
            track("t", -2.5).validate();
        };
        a["track_inf_length"] = [track] {
            track("t", std::numeric_limits<double>::infinity())
                    .validate();
        };
        a["track_unknown_surface"] = [track] {
            track("bad", 10.0, {}, "ice").validate();
        };
        a["obstacle_outside"] = [track] {
            track("t", 10.0,
                  {std::make_shared<terrain::SquareEdge>(9.9, 0.090,
                                                         0.250)})
                    .validate();
        };
        a["obstacle_negative_start"] = [track] {
            track("t", 10.0,
                  {std::make_shared<terrain::SquareEdge>(-0.5)})
                    .validate();
        };
        a["obstacle_overlap"] = [track] {
            track("t", 30.0,
                  {std::make_shared<terrain::Washboard>(5.0, 0.035,
                                                        0.9, 9),
                   std::make_shared<terrain::Pothole>(12.0)})
                    .validate();
        };
        a["obstacle_touch_ok"] = [track] {
            track("t", 30.0,
                  {std::make_shared<terrain::Pothole>(5.0, 0.180, 0.5),
                   std::make_shared<terrain::Pothole>(5.5)})
                    .validate();
        };
        a["grade_single_knot"] = [] {
            (void)terrain::GradeProfile({{0.0, 0.1}});
        };
        a["grade_nonzero_start"] = [] {
            (void)terrain::GradeProfile({{1.0, 0.1}, {2.0, 0.2}});
        };
        a["grade_decreasing"] = [] {
            (void)terrain::GradeProfile({{0.0, 0.1}, {0.0, 0.2}});
        };
        a["grade_nan_knot"] = [] {
            (void)terrain::GradeProfile(
                    {{0.0, 0.1},
                     {5.0, std::numeric_limits<double>::quiet_NaN()}});
        };
        a["grade_beyond_track"] = [track] {
            terrain::TrackSpec t = track("t", 5.0);
            t.grade_profile = terrain::GradeProfile(
                    {{0.0, 0.0}, {10.0, 0.1}});
            t.validate();
        };
        a["grade_query_nan"] = [] {
            const terrain::GradeProfile gp({{0.0, 0.0}, {10.0, 0.1}});
            (void)gp.slope(std::numeric_limits<double>::quiet_NaN());
        };
        a["surface_section_reversed"] = [] {
            (void)terrain::SurfaceSection(5.0, 2.0, "wet");
        };
        a["surface_section_negative"] = [] {
            (void)terrain::SurfaceSection(-1.0, 2.0, "wet");
        };
        a["surface_section_unknown"] = [] {
            (void)terrain::SurfaceSection(0.0, 2.0, "ice");
        };
        a["surface_section_nan"] = [] {
            (void)terrain::SurfaceSection(
                    0.0, std::numeric_limits<double>::quiet_NaN(), "wet");
        };
        a["surface_map_overlap"] = [] {
            (void)terrain::SurfaceMap(
                    terrain::get_surface("hardpack"),
                    {terrain::SurfaceSection(5.0, 10.0, "wet"),
                     terrain::SurfaceSection(9.0, 12.0, "loose")});
        };
        a["surface_map_touch_ok"] = [] {
            (void)terrain::SurfaceMap(
                    terrain::get_surface("hardpack"),
                    {terrain::SurfaceSection(5.0, 10.0, "wet"),
                     terrain::SurfaceSection(10.0, 12.0, "loose")});
        };
        a["material_beyond_track"] = [track] {
            terrain::TrackSpec t = track("t", 8.0);
            t.surface_sections = {terrain::SurfaceSection(5.0, 10.0,
                                                          "wet")};
            t.validate();
        };
        a["get_surface_unknown"] = [] {
            (void)terrain::get_surface("ice");
        };
        a["surface_spec_negative"] = [] {
            (void)terrain::SurfaceSpec("bad", -1.0, 0.4, 10.0);
        };
        a["surface_spec_slide_over_peak"] = [] {
            (void)terrain::SurfaceSpec("bad", 0.4, 0.5, 10.0);
        };
        a["surface_spec_nan"] = [] {
            (void)terrain::SurfaceSpec(
                    "bad", std::numeric_limits<double>::quiet_NaN(), 0.4,
                    10.0);
        };
        a["surface_mu_nan"] = [] {
            (void)terrain::get_surface("asphalt")
                    .mu(std::numeric_limits<double>::quiet_NaN());
        };
        a["surface_mu_inf"] = [] {
            (void)terrain::get_surface("asphalt")
                    .mu(std::numeric_limits<double>::infinity());
        };
        a["map_at_nan"] = [] {
            const terrain::SurfaceMap map(
                    terrain::get_surface("hardpack"),
                    {terrain::SurfaceSection(5.0, 10.0, "wet"),
                     terrain::SurfaceSection(30.0, 40.0, "loose")});
            (void)map.at(std::numeric_limits<double>::quiet_NaN());
        };
        a["road_negative_rate"] = [] {
            terrain::RoadGeneratorSpec spec;
            spec.potholes_per_100m = -1.0;
            spec.validate();
        };
        a["road_inverted_range"] = [] {
            terrain::RoadGeneratorSpec spec;
            spec.pothole_depth_m = {0.5, 0.2};
            spec.validate();
        };
        a["road_negative_range_end"] = [] {
            terrain::RoadGeneratorSpec spec;
            spec.bump_length_m = {-0.5, 0.2};
            spec.validate();
        };
        a["road_bad_edge_name"] = [] {
            terrain::RoadGeneratorSpec spec;
            spec.pothole_edge = {{"bogus", 1.0}};
            spec.validate();
        };
        a["road_zero_weights"] = [] {
            terrain::RoadGeneratorSpec spec;
            spec.pothole_edge = {};
            spec.validate();
        };
        a["road_negative_weight"] = [] {
            terrain::RoadGeneratorSpec spec;
            spec.pothole_edge = {{"sharp", -0.5}, {"sloped", 2.0}};
            spec.validate();
        };
        a["road_bad_ramp_fraction"] = [] {
            terrain::RoadGeneratorSpec spec;
            spec.bump_ramp_fraction = 0.7;
            spec.validate();
        };
        a["road_no_room"] = [] {
            (void)terrain::generate_road(terrain::RoadGeneratorSpec{},
                                         5.0);
        };
        a["heightfield_wrong_count"] = [] {
            const std::array<double, 5> bad{};
            (void)terrain::FIELD.normalize(bad);
        };
        a["heightfield_extent_escape"] = [] {
            const std::vector<double> escape = terrain::detail::
                    np_linspace(-4.0, 0.0,
                                static_cast<std::size_t>(
                                        terrain::FIELD.ncol));
            (void)terrain::FIELD.normalize(escape);
        };
        a["profile_query_nan_center"] = [] {
            const biketyre::ProfileQuery q({0.0, 1.0}, {0.0, 0.0}, 0.0001,
                                     0.05, 20.0);
            (void)q.contact(
                    {std::numeric_limits<double>::quiet_NaN(), 0.5},
                    0.372, std::nullopt);
        };
        a["profile_query_below_road"] = [] {
            const biketyre::ProfileQuery q({0.0, 1.0}, {0.0, 0.0}, 0.0001,
                                     0.05, 20.0);
            (void)q.contact({0.5, -0.1}, 0.372, std::nullopt);
        };
        a["profile_query_outside"] = [] {
            const biketyre::ProfileQuery q({0.0, 1.0}, {0.0, 0.0}, 0.0001,
                                     0.05, 20.0);
            (void)q.contact({2.0, 0.5}, 0.372, std::nullopt);
        };
        a["profile_query_bad_radius"] = [] {
            const biketyre::ProfileQuery q({0.0, 1.0}, {0.0, 0.0}, 0.0001,
                                     0.05, 20.0);
            (void)q.contact({0.5, 0.5}, 0.0, std::nullopt);
        };
        a["profile_query_degenerate"] = [] {
            const biketyre::ProfileQuery q({0.0, 1.0}, {0.0, 0.0}, 0.0001,
                                     0.05, 20.0);
            (void)q.contact({0.5, 1e-14}, 0.372, std::nullopt);
        };
        a["profile_query_bad_vertices"] = [] {
            const biketyre::ProfileQuery q({0.0}, {0.0}, 0.0001, 0.05, 20.0);
        };
        a["profile_query_dup_x"] = [] {
            const biketyre::ProfileQuery q({0.0, 0.5, 0.5}, {0.0, 0.0, 1.0},
                                     0.0001, 0.05, 20.0);
        };
        a["signed_profile_bad_vertices"] = [] {
            (void)biketyre::SignedProfile({{0.0, 0.0}, {0.0, 1.0}});
        };
        a["signed_profile_duplicate_x"] = [] {
            (void)biketyre::SignedProfile(
                    {{0.0, 0.0}, {0.5, 0.0}, {0.5, 1.0}});
        };
        a["signed_profile_nonfinite"] = [] {
            (void)biketyre::SignedProfile(
                    {{0.0, 0.0},
                     {0.5, std::numeric_limits<double>::quiet_NaN()}});
        };
        a["signed_profile_height_outside"] = [] {
            const std::vector<std::array<double, 2>> verts = {
                    {0.0, 0.0},   {1.0, 0.0},    {1.5, -0.18},
                    {2.1, -0.18}, {2.6, 0.0},    {4.0, 0.0},
                    {4.3, 0.09},  {4.55, 0.09},  {4.8, 0.0},
                    {6.0, 0.0}};
            const biketyre::SignedProfile sp(verts);
            (void)sp.height(6.5);
        };
        a["signed_profile_height_nan"] = [] {
            const std::vector<std::array<double, 2>> verts = {
                    {0.0, 0.0},   {1.0, 0.0},    {1.5, -0.18},
                    {2.1, -0.18}, {2.6, 0.0},    {4.0, 0.0},
                    {4.3, 0.09},  {4.55, 0.09},  {4.8, 0.0},
                    {6.0, 0.0}};
            const biketyre::SignedProfile sp(verts);
            (void)sp.height(std::numeric_limits<double>::quiet_NaN());
        };
        a["signed_profile_query_bad"] = [] {
            const std::vector<std::array<double, 2>> verts = {
                    {0.0, 0.0},   {1.0, 0.0},    {1.5, -0.18},
                    {2.1, -0.18}, {2.6, 0.0},    {4.0, 0.0},
                    {4.3, 0.09},  {4.55, 0.09},  {4.8, 0.0},
                    {6.0, 0.0}};
            const biketyre::SignedProfile sp(verts);
            (void)sp.query(
                    {0.1, std::numeric_limits<double>::quiet_NaN()});
        };
        return a;
    }();
    for (const Value &c :
         array_of(member(doc, "cases", "doc"), "doc")) {
        const std::string &name = str_member(c, "case", "case");
        const auto it = actions.find(name);
        if (it == actions.end()) continue;
        const Value *error = member_opt(c, "error", "case");
        const std::string py_error =
                (error != nullptr &&
                 !std::holds_alternative<std::monostate>(error->data))
                ? string_of(*error, "case")
                : "";
        const std::string expected =
                (error != nullptr &&
                 !std::holds_alternative<std::monostate>(error->data))
                ? string_of(member(c, "message", "case"), "case")
                : "";
        if (py_error.empty()) {
            // Cases the oracle accepts must complete.
            it->second();
        } else {
            expect_msg(expected, py_error, it->second, name);
        }
    }
    // Scalar property captures.
    const Value &scalars = member(doc, "scalars", "doc");
    expect_bits(num_member(scalars, "stepped_climb_datum", "s"),
                terrain::SteppedClimb(15.0).datum_shift_m(),
                "stepped datum");
    expect_bits(num_member(scalars, "stepped_climb_short_datum", "s"),
                terrain::SteppedClimb(
                        15.0,
                        std::vector<std::array<double, 2>>{{8.0, 10.0},
                                                           {16.0, 10.0}},
                        2.5)
                        .datum_shift_m(),
                "stepped short datum");
    expect_bits(num_member(scalars, "kicker_launch_angle", "s"),
                terrain::Kicker(57.0, 0.350, 1.400, 2.500, 20.0, 5.0)
                        .launch_angle_deg(),
                "kicker launch");
    expect_bits(num_member(scalars, "kicker_landing_drop", "s"),
                terrain::Kicker(57.0, 0.350, 1.400, 2.500, 20.0, 5.0)
                        .landing_drop_m(),
                "kicker landing");
    expect_bits(num_member(scalars, "kicker_default_landing_drop", "s"),
                terrain::Kicker(57.0).landing_drop_m(),
                "kicker default landing");
}

} // namespace

int main() {
    return bt::run([] {
        test_obstacle_elevations();
        test_rock_nodes();
        test_track_fields();
        test_road_obstacles();
        test_grade();
        test_surface();
        test_heightfield();
        test_wheelpath();
        test_contact_safety();
        test_profile_kernels();
        test_convenience();
        test_validation();
    });
}
