// terrain/types.hpp — T20 record/type boundary for the owned terrain
// sources:
//   grade.py       GradeProfile (frozen knot record)
//   obstacles.py   Obstacle ABC + the 14 concrete obstacle dataclasses
//   surface.py     SurfaceSpec registry, SurfaceSection, SurfaceMap,
//                  DEFAULT_STRIBECK_SPEED_MPS and the surface-name
//                  constants
//   profile.py     TrackSpec (profile.cpp owns the methods that need
//                  build_profile/validate ordering)
//   heightfield.py HeightFieldSpec + FIELD constant
//   road.py        RoadGeneratorSpec + range/interval types
//
// The function-level APIs (build_profile, wheel_centre_path,
// single_contact_hazards, build_field_data, generate_road, …) are
// declared in terrain/profile.hpp; this header owns only the records and
// the numeric detail they share.
//
// Bitwise contract beyond the ordinary scalar expressions (all verified
// against the NumPy 2.5.2 / SciPy 1.17 / CPython 3.14.3 oracle pinned in
// tests/fixtures/migration/terrain/):
//   np.arange       — ctors.c PyArray_Arange + arraytypes DOUBLE_fill:
//                     len = ceil((stop-start)/step) with the tmp_len==0
//                     underflow split; out[0]=start, out[1]=start+step,
//                     stored step = out[1]-out[0], out[i]=start+i*step.
//                     NOT the naive start+i*step formula (mismatches on
//                     nonzero starts, e.g. -0.744 over 4177 samples).
//   np.linspace     — fl(i*step)+start per element, last pinned to stop.
//   np.interp       — binary-search knot then fma(slope, x-xp[j], fp[j])
//                     with the NaN retry from the j+1 knot (same port as
//                     tyre/profile.cpp's np_interp).
//   np.clip scalar  — const-minmax fast path: x<lo?lo:(x>hi?hi:x).
//   np.min/np.max   — numeric::np_minimum/np_maximum folds.
//   np.sum/.sum()   — numeric::numpy_pairwise_sum.
//   builtin sum()   — numeric::PythonSum (Neumaier).
//   round(x)        — rint (ties-to-even); round(x,n) — to_chars fixed-n
//                     + strtod (CPython _Py_dg_dtoa mode-3 equivalent).
//   float formatting— py_repr/py_fixed/py_g/py_fixed_signed mirror the
//                     f-string renderings used in oracle messages/labels.
//   scipy gaussian  — _gaussian_kernel1d + NI_Correlate1D: symmetry
//                     detection, 'nearest' (clamped-index) borders, and
//                     the platform extension's fma-contracted
//                     accumulation (verified 0/600 bitwise probes).
//   Python ** pow   — scalar x**y → std::pow; np.power(x,2) → x*x.
//   np.degrees/     — x*(180/NPY_PI) / x*(NPY_PI/180) single multiply.
//   np.radians
#pragma once

#include <algorithm>
#include <array>
#include <bit>
#include <charconv>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "../numeric_numpy.hpp"
#include "../numeric_sum.hpp"

namespace bike::terrain {

// ---------------------------------------------------------------------------
// detail — the numpy/CPython/scipy lowerings the terrain port shares. These
// mirror the verified implementations in tyre/profile.cpp and
// geometry/specs.hpp; each boundary carries its own documented lowering set
// so the terrain leaf stays free of cross-package internals.
// ---------------------------------------------------------------------------
namespace detail {

// np.arange(start, stop, step) float64 — PyArray_Arange + DOUBLE_fill
// (ctors.c:3094, arraytypes.c.src:3803).
// NOLINTBEGIN(bugprone-easily-swappable-parameters) positional args mirror np.arange
[[nodiscard]] inline std::vector<double>
np_arange(double start, double stop, double step) {
    // NOLINTEND(bugprone-easily-swappable-parameters)
    const double delta = stop - start;
    const double tmp_len = delta / step;
    std::int64_t length = 0;
    if (tmp_len == 0.0 && delta != 0.0) {
        // Underflow divide: the sign of tmp_len decides empty vs 1.
        length = std::signbit(tmp_len) ? 0 : 1;
    } else {
        const double ivalue = std::ceil(tmp_len);
        if (std::isnan(ivalue))
            throw std::invalid_argument("arange: cannot compute length");
        if (!(ivalue >= static_cast<double>(std::numeric_limits<std::int64_t>::min()) &&
              ivalue <= static_cast<double>(std::numeric_limits<std::int64_t>::max())))
            throw std::overflow_error(
                    "arange: overflow while computing length");
        length = static_cast<std::int64_t>(ivalue);
    }
    if (length <= 0) return {};
    std::vector<double> out(static_cast<std::size_t>(length));
    out[0] = start;
    if (length == 1) return out;
    out[1] = start + step;
    if (length == 2) return out;
    // DOUBLE_fill: the stored step is buffer[1]-buffer[0], not `step`; the
    // shipped wheel compiles buffer[i]=start+i*delta to fmadd — explicit
    // fma under -ffp-contract=off.
    const double stored = out[1] - out[0];
    for (std::size_t i = 2; i < out.size(); ++i)
        out[i] = std::fma(static_cast<double>(i), stored, start);
    return out;
}

// np.linspace(start, stop, num) float64 endpoint=True: y[i]=fl(i*step)+start
// (i*step is the arange product), y[num-1]=stop (function_base.py).
[[nodiscard]] inline std::vector<double>
np_linspace(double start, double stop, std::size_t num) {
    std::vector<double> y(num);
    if (num == 0) return y;
    if (num == 1) {
        y[0] = start;
        return y;
    }
    const double step = (stop - start) / static_cast<double>(num - 1);
    for (std::size_t i = 0; i + 1 < num; ++i)
        y[i] = static_cast<double>(i) * step + start;
    y[num - 1] = stop;
    return y;
}

// np.interp(x, xs, ys) scalar — compiled_base.c arr_interp inner loop:
// largest j with xs[j] <= x, endpoint clamps, exact-hit return, fma slope
// form, NaN retry from the j+1 knot, flat-y tie-break.
[[nodiscard]] inline double
np_interp(double xq, std::span<const double> xs,
          std::span<const double> ys) {
    if (xs.empty() || xs.size() != ys.size())
        throw std::invalid_argument(
                "interp tables must be nonempty and equally wide");
    const std::size_t n = xs.size();
    const double lval = ys.front();
    const double rval = ys.back();
    int j = 0;
    if (xq < xs.front())
        j = -1;
    else if (xq > xs.back())
        j = static_cast<int>(n);
    else
        j = static_cast<int>(
                std::ranges::upper_bound(xs, xq) - xs.begin()) - 1;
    if (j == -1) return lval;
    if (std::cmp_equal(j, n)) return rval;
    if (std::cmp_equal(j, n - 1)) return rval;
    const std::size_t ju = static_cast<std::size_t>(j);
    if (xs[ju] == xq) return ys[ju];
    const double slope = (ys[ju + 1] - ys[ju]) / (xs[ju + 1] - xs[ju]);
    double result = std::fma(slope, xq - xs[ju], ys[ju]);
    if (std::isnan(result)) {
        result = std::fma(slope, xq - xs[ju + 1], ys[ju + 1]);
        if (std::isnan(result) && ys[ju] == ys[ju + 1]) result = ys[ju];
    }
    return result;
}

// np.clip(x, lo, hi) scalar bounds — clip.cpp _npy_clip_const_minmax_
// floating fast path.
// NOLINTBEGIN(bugprone-easily-swappable-parameters) positional args mirror np.clip
[[nodiscard]] inline double
np_clip_scalar(double x, double lo, double hi) noexcept {
    // NOLINTEND(bugprone-easily-swappable-parameters)
    if (x < lo) x = lo;
    if (x > hi) x = hi;
    return x;
}
// np.clip(x, lo, None) — the min-only scalar bound path.
[[nodiscard]] inline double np_clip_min(double x, double lo) noexcept {
    if (x < lo) x = lo;
    return x;
}
// np.clip(x, None, hi) — the max-only scalar bound path.
[[nodiscard]] inline double np_clip_max(double x, double hi) noexcept {
    if (x > hi) x = hi;
    return x;
}

// np.radians / np.degrees — x * NPY_PI_180 / x * NPY_180_PI single multiply
// (npy_math_internal.h.src DEG2RAD / RAD2DEG constants).
[[nodiscard]] inline double np_radians(double deg) noexcept {
    return deg * 0.017453292519943295;
}
[[nodiscard]] inline double np_degrees(double rad) noexcept {
    return rad * 57.29577951308232;
}

// np.diff(v) — adjacent elementwise differences.
[[nodiscard]] inline std::vector<double>
np_diff(std::span<const double> v) {
    std::vector<double> out(v.size() > 0 ? v.size() - 1 : 0);
    for (std::size_t i = 0; i < out.size(); ++i) out[i] = v[i + 1] - v[i];
    return out;
}

// np.max / np.min folds via the NEON-fmaxnm/fminnm twins.
[[nodiscard]] inline double np_max(std::span<const double> v) {
    double acc = v.front();
    for (const double x : v.subspan(1)) acc = numeric::np_maximum(acc, x);
    return acc;
}
[[nodiscard]] inline double np_min(std::span<const double> v) {
    double acc = v.front();
    for (const double x : v.subspan(1)) acc = numeric::np_minimum(acc, x);
    return acc;
}
[[nodiscard]] inline double np_max_abs(std::span<const double> v) {
    double acc = std::fabs(v.front());
    for (const double x : v.subspan(1))
        acc = numeric::np_maximum(acc, std::fabs(x));
    return acc;
}

// np.unique(v): sorted unique values.
[[nodiscard]] inline std::vector<double>
np_sort_unique(std::vector<double> v) {
    std::ranges::sort(v);
    const auto last = std::ranges::unique(v).begin();
    v.erase(last, v.end());
    return v;
}

// Python round(x) — nearest integer with ties-to-even (CPython round()
// on floats equals rint for every binary64 input).
[[nodiscard]] inline double py_round_int(double x) noexcept {
    return std::nearbyint(x);
}

// Python round(x, n) — CPython _Py_double_round: correctly-rounded
// decimal rounding, equal to fixed-n formatting + parse for finite x.
[[nodiscard]] inline double py_round_digits(double x, int digits) {
    if (!std::isfinite(x)) return x;
    std::array<char, 64> buf{};
    const auto out = std::to_chars(buf.data(), std::to_address(buf.end()), x,
                                   std::chars_format::fixed, digits);
    double result = 0.0;
    (void)std::from_chars(buf.data(), out.ptr, result,
                          std::chars_format::fixed);
    return result;
}

// Python min(a, b) / max(a, b) two-argument semantics (a wins ties).
[[nodiscard]] inline double py_min2(double a, double b) noexcept {
    return b < a ? b : a;
}
[[nodiscard]] inline double py_max2(double a, double b) noexcept {
    return b > a ? b : a;
}

// Python repr(float) — shortest round-trip digits; fixed notation for
// decimal exponent in [-4, 16), scientific 'e±NN' (>=2 digits) otherwise.
[[nodiscard]] inline std::string py_repr(double x) {
    if (std::isnan(x)) return "nan";
    if (std::isinf(x)) return x < 0.0 ? "-inf" : "inf";
    if (x == 0.0) return std::signbit(x) ? "-0.0" : "0.0";
    std::array<char, 64> buf{};
    const auto sci = std::to_chars(buf.data(), std::to_address(buf.end()), x,
                                   std::chars_format::scientific);
    const std::string s(buf.data(), sci.ptr);
    const std::size_t epos = s.find('e');
    std::string mant = s.substr(0, epos);
    const int exp = std::stoi(s.substr(epos + 1));
    const bool neg = mant.front() == '-';
    if (neg) mant.erase(0, 1);
    std::string digits;
    for (const char c : mant)
        if (c != '.') digits.push_back(c);
    std::string out;
    if (neg) out.push_back('-');
    if (exp >= -4 && exp < 16) {
        const int ip = exp + 1;
        if (ip <= 0) {
            out += "0.";
            out.append(static_cast<std::size_t>(-ip), '0');
            out += digits;
        } else {
            out += digits.substr(0, static_cast<std::size_t>(ip));
            if (static_cast<std::size_t>(ip) < digits.size()) {
                out.push_back('.');
                out += digits.substr(static_cast<std::size_t>(ip));
            } else {
                out.append(static_cast<std::size_t>(ip) - digits.size(),
                           '0');
                out += ".0";
            }
        }
    } else {
        out.push_back(digits[0]);
        if (digits.size() > 1) {
            out.push_back('.');
            out += digits.substr(1);
        }
        out.push_back('e');
        out.push_back(exp < 0 ? '-' : '+');
        const std::string es = std::to_string(exp < 0 ? -exp : exp);
        if (es.size() < 2) out.push_back('0');
        out += es;
    }
    return out;
}

// Python '{:.Nf}' fixed format.
[[nodiscard]] inline std::string py_fixed(double x, int precision) {
    if (std::isnan(x)) return "nan";
    if (std::isinf(x)) return x < 0.0 ? "-inf" : "inf";
    std::array<char, 256> buf{};
    const auto out = std::to_chars(buf.data(), std::to_address(buf.end()), x,
                                   std::chars_format::fixed, precision);
    return {buf.data(), out.ptr};
}

// Python '{:+.Nf}' — explicit sign on non-negative values.
[[nodiscard]] inline std::string py_fixed_signed(double x, int precision) {
    const std::string body = py_fixed(x, precision);
    return (!body.empty() && body.front() != '-') ? "+" + body : body;
}

// Python '{:g}' / '{:.Pg}' general format — P significant digits.
[[nodiscard]] inline std::string py_g(double x, int precision = 6) {
    if (std::isnan(x)) return "nan";
    if (std::isinf(x)) return x < 0.0 ? "-inf" : "inf";
    std::array<char, 128> buf{};
    const auto out = std::to_chars(buf.data(), std::to_address(buf.end()), x,
                                   std::chars_format::general, precision);
    return {buf.data(), out.ptr};
}

// Python repr() of a sorted list of strings — "['a', 'b']" (single
// quotes), used by the road.py unknown-shape message.
[[nodiscard]] inline std::string
py_str_list_repr(std::span<const std::string_view> items) {
    std::string out = "[";
    bool first = true;
    for (const std::string_view s : items) {
        if (!first) out += ", ";
        first = false;
        out += '\'';
        out += s;
        out += '\'';
    }
    out += ']';
    return out;
}

// np.random.default_rng(seed) entropy coercion: bit_generator.pyx raises
// ValueError("expected non-negative integer") for a negative seed.
[[nodiscard]] inline std::uint64_t np_seed_u64(std::int64_t seed) {
    if (seed < 0)
        throw std::invalid_argument("expected non-negative integer");
    return static_cast<std::uint64_t>(seed);
}

// scipy.ndimage._filters._gaussian_kernel1d(sigma, order=0, radius):
// x = arange(-r, r+1); phi = exp(-0.5/sigma^2 * x**2); phi / phi.sum().
// sigma must be > 0; the oracle call site always uses sigma=1, lw=4.
// NOLINTBEGIN(bugprone-easily-swappable-parameters) (sigma, radius) mirrors _gaussian_kernel1d
[[nodiscard]] inline std::vector<double>
gaussian_kernel1d(double sigma, int radius) {
    // NOLINTEND(bugprone-easily-swappable-parameters)
    std::vector<double> phi(static_cast<std::size_t>(2 * radius + 1));
    const double sigma2 = sigma * sigma;
    for (std::ptrdiff_t i = -radius; i <= radius; ++i) {
        const double x = static_cast<double>(i);
        phi[static_cast<std::size_t>(i + radius)] =
                std::exp(-0.5 / sigma2 * (x * x));
    }
    const double s = numeric::numpy_pairwise_sum(phi);
    for (double &v : phi) v /= s;
    return phi;
}

// scipy.ndimage correlate1d(input, weights, mode='nearest') — the
// NI_Correlate1D port: odd-size symmetry dispatch, the symmetric/anti-
// symmetric fast paths (center tap first, then paired endpoints from the
// outside in) and the general path (rightmost tap first, then left-to-
// right). Every += product is the extension's fma-contracted fmadd.
[[nodiscard]] inline std::vector<double>
correlate1d_nearest(std::span<const double> input,
                    std::span<const double> weights) {
    const std::size_t n = input.size();
    const std::size_t k = weights.size();
    const std::ptrdiff_t s1 = static_cast<std::ptrdiff_t>(k / 2);
    const std::ptrdiff_t s2 =
            static_cast<std::ptrdiff_t>(k) - s1 - 1;
    int symmetric = 0;
    if (k & 1U) {
        symmetric = 1;
        for (std::ptrdiff_t i = 1; i <= s1; ++i) {
            if (std::fabs(weights[static_cast<std::size_t>(s1 + i)] -
                          weights[static_cast<std::size_t>(s1 - i)]) >
                std::numeric_limits<double>::epsilon()) {
                symmetric = 0;
                break;
            }
        }
        if (symmetric == 0) {
            symmetric = -1;
            for (std::ptrdiff_t i = 1; i <= s1; ++i) {
                if (std::fabs(weights[static_cast<std::size_t>(s1 + i)] +
                              weights[static_cast<std::size_t>(s1 - i)]) >
                    std::numeric_limits<double>::epsilon()) {
                    symmetric = 0;
                    break;
                }
            }
        }
    }
    const auto ext = [&](std::ptrdiff_t i) -> double {
        if (i < 0) return input.front();
        if (std::cmp_greater_equal(i, n)) return input.back();
        return input[static_cast<std::size_t>(i)];
    };
    std::vector<double> out(n);
    for (std::size_t i = 0; i < n; ++i) {
        const std::ptrdiff_t ii = static_cast<std::ptrdiff_t>(i);
        double acc = 0.0;
        if (symmetric > 0) {
            acc = ext(ii) * weights[static_cast<std::size_t>(s1)];
            for (std::ptrdiff_t jj = -s1; jj < 0; ++jj)
                acc = std::fma(
                        ext(ii + jj) + ext(ii - jj),
                        weights[static_cast<std::size_t>(s1 + jj)], acc);
        } else if (symmetric < 0) {
            acc = ext(ii) * weights[static_cast<std::size_t>(s1)];
            for (std::ptrdiff_t jj = -s1; jj < 0; ++jj)
                acc = std::fma(
                        ext(ii + jj) - ext(ii - jj),
                        weights[static_cast<std::size_t>(s1 + jj)], acc);
        } else {
            acc = ext(ii + s2) * weights[static_cast<std::size_t>(s1 + s2)];
            for (std::ptrdiff_t jj = -s1; jj < s2; ++jj)
                acc = std::fma(ext(ii + jj),
                               weights[static_cast<std::size_t>(s1 + jj)],
                               acc);
        }
        out[i] = acc;
    }
    return out;
}

// scipy.ndimage.gaussian_filter1d(input, sigma, mode='nearest', order=0,
// truncate=4.0): lw = int(truncate*sd + 0.5); correlate with the reversed
// kernel (the reversal is a no-op for the symmetric Gaussian).
[[nodiscard]] inline std::vector<double>
gaussian_filter1d_nearest(std::span<const double> input, double sigma) {
    // scipy's int() is trunc-toward-zero by design — lw = int(truncate*sd + 0.5)
    const int lw = static_cast<int>(4.0 * sigma + 0.5); // NOLINT(bugprone-incorrect-roundings) intentional truncation, see above
    const std::vector<double> kernel = gaussian_kernel1d(sigma, lw);
    std::vector<double> reversed(kernel.rbegin(), kernel.rend());
    return correlate1d_nearest(input, reversed);
}

} // namespace detail

// ---------------------------------------------------------------------------
// surface.py — friction records and registry (surface.cpp implements the
// validating constructors and methods).
// ---------------------------------------------------------------------------

inline constexpr double DEFAULT_STRIBECK_SPEED_MPS = 4.5;
inline constexpr std::string_view ROAD_SURFACE = "asphalt";
inline constexpr std::string_view TRAIL_SURFACE = "hardpack";
inline constexpr std::string_view DEFAULT_SURFACE = TRAIL_SURFACE;

// SurfaceSpec (surface.py:31-92) — frozen registry record. Construction
// validates: every coefficient positive finite ('invalid SurfaceSpec.<f>'
// from the shared scalar() gate), then mu_slide <= mu_peak.
struct SurfaceSpec {
    std::string name;
    double mu_peak = 0.0;
    double mu_slide = 0.0;
    double slip_stiffness_per_load = 0.0;
    double stribeck_speed_mps = DEFAULT_STRIBECK_SPEED_MPS;
    std::string description;

    SurfaceSpec() = default;
    SurfaceSpec(std::string name_, double mu_peak_, double mu_slide_,
                double slip_stiffness_per_load_,
                double stribeck_speed_mps_ = DEFAULT_STRIBECK_SPEED_MPS,
                std::string description_ = "") {
        // checks.scalar(value, label, positive=True) → 'invalid <label>'.
        for (const auto &[label, value] : {
                 std::pair<std::string_view, double>{"SurfaceSpec.mu_peak",
                                                     mu_peak_},
                 {"SurfaceSpec.mu_slide", mu_slide_},
                 {"SurfaceSpec.slip_stiffness_per_load",
                  slip_stiffness_per_load_},
                 {"SurfaceSpec.stribeck_speed_mps", stribeck_speed_mps_}}) {
            if (!std::isfinite(value) || value <= 0.0)
                throw std::invalid_argument("invalid " + std::string(label));
        }
        if (mu_slide_ > mu_peak_)
            throw std::invalid_argument(
                    "surface '" + name_ + "': mu_slide " +
                    detail::py_repr(mu_slide_) + " exceeds mu_peak " +
                    detail::py_repr(mu_peak_));
        name = std::move(name_);
        mu_peak = mu_peak_;
        mu_slide = mu_slide_;
        slip_stiffness_per_load = slip_stiffness_per_load_;
        stribeck_speed_mps = stribeck_speed_mps_;
        description = std::move(description_);
    }

    // mu(v) = mu_slide + (mu_peak - mu_slide) * exp(-|v| / stribeck) —
    // scalar path; the array() gate rejects non-finite queries with
    // 'invalid shape or non-finite SurfaceSpec.sliding_speed_mps'.
    [[nodiscard]] double mu(double sliding_speed_mps) const;
};

// SurfaceSection (surface.py:146-164) — half-open material interval.
struct SurfaceSection {
    double start_m = 0.0;
    double end_m = 0.0;
    std::string surface;

    SurfaceSection() = default;
    SurfaceSection(double start, double end, std::string surface_name);
};

// SurfaceMap (surface.py:167-236) — base material plus sorted,
// non-overlapping half-open sections.
class SurfaceMap {
public:
    SurfaceMap(SurfaceSpec surface, std::vector<SurfaceSection> sections);
    static SurfaceMap uniform(std::string_view name);

    [[nodiscard]] const SurfaceSpec &at(double x_m) const;
    [[nodiscard]] const SurfaceSpec &base() const noexcept {
        return surface_;
    }
    [[nodiscard]] const std::vector<SurfaceSection> &sections()
            const noexcept {
        return sections_;
    }
    [[nodiscard]] std::vector<SurfaceSpec> surfaces() const;
    [[nodiscard]] std::string name() const;
    void validate() const;

private:
    SurfaceSpec surface_;
    std::vector<SurfaceSection> sections_;
};

// ---------------------------------------------------------------------------
// grade.py — piecewise-linear grade integrated to a C1 elevation.
// ---------------------------------------------------------------------------

class GradeProfile {
public:
    // knots: (station_m, grade) pairs — at least two, finite, stations
    // starting at zero and strictly increasing (grade.py:20-33).
    explicit GradeProfile(std::vector<std::array<double, 2>> knots);

    [[nodiscard]] const std::vector<std::array<double, 2>> &knots()
            const noexcept {
        return knots_;
    }
    // slope(x) = np.interp(x, stations, grades) — endpoint grades held
    // outside the knot range. Rejects non-finite queries.
    [[nodiscard]] double slope(double x) const;
    [[nodiscard]] std::vector<double> slope(std::span<const double> x) const;
    // elevation(x): trapezoidal integral between knots, linear extension
    // beyond both ends. Rejects non-finite queries.
    [[nodiscard]] double elevation(double x) const;
    [[nodiscard]] std::vector<double>
    elevation(std::span<const double> x) const;

private:
    std::vector<std::array<double, 2>> knots_;
};

// ---------------------------------------------------------------------------
// obstacles.py — the obstacle catalogue (obstacles.cpp implements the
// elevation formulas; contact_safety reads nodes() on RockGarden like the
// oracle's _nodes()).
// ---------------------------------------------------------------------------

class Obstacle {
public:
    explicit Obstacle(double start_m_) : start_m(start_m_) {}
    virtual ~Obstacle() = default;
    // Polymorphic base: obstacles are only stored behind shared_ptr and
    // never copied — deleting the ops documents that and satisfies the
    // special-member rule.
    Obstacle(const Obstacle &) = delete;
    Obstacle &operator=(const Obstacle &) = delete;
    Obstacle(Obstacle &&) = delete;
    Obstacle &operator=(Obstacle &&) = delete;

    double start_m;

    // Local longitudinal extent (obstacles.py:36-38).
    [[nodiscard]] virtual double length_m() const = 0;
    // Permanent downstream road-level change (default 0). Out-of-line in
    // obstacles.cpp — the class key function, so the vtable is emitted
    // in one TU.
    [[nodiscard]] virtual double datum_shift_m() const;
    [[nodiscard]] double end_m() const { return start_m + length_m(); }
    // '{ClassName}@{start_m:.0f}m'.
    [[nodiscard]] std::string label() const {
        return std::string(class_name()) + "@" +
               detail::py_fixed(start_m, 0) + "m";
    }
    // Whether the obstacle earns a plot/HUD marker (RoadRoughness: false).
    [[nodiscard]] virtual bool annotate() const { return true; }

    // elevation(s): height contribution for local s — elementwise like the
    // oracle's masked array math; out must have s.size() slots.
    virtual void elevation(std::span<const double> s,
                           std::span<double> out) const = 0;
    [[nodiscard]] std::vector<double>
    elevation(std::span<const double> s) const {
        std::vector<double> out(s.size());
        elevation(s, out);
        return out;
    }
    [[nodiscard]] double elevation_at(double s) const {
        double out = 0.0;
        const double in = s;
        elevation(std::span<const double>(&in, 1),
                  std::span<double>(&out, 1));
        return out;
    }
    // type(self).__name__ — used by labels and hazard strings.
    [[nodiscard]] virtual std::string_view class_name() const = 0;
};

class SquareEdge final : public Obstacle {
public:
    double height_m = 0.090;
    double ledge_length_m = 0.250;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit SquareEdge(double start_m_, double height_m_ = 0.090,
                        double ledge_length_m_ = 0.250)
        : Obstacle(start_m_), height_m(height_m_),
          ledge_length_m(ledge_length_m_) {}
    [[nodiscard]] double length_m() const override {
        return ledge_length_m;
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "SquareEdge";
    }
};

class Pothole final : public Obstacle {
public:
    double depth_m = 0.180;
    double hole_length_m = 0.600;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit Pothole(double start_m_, double depth_m_ = 0.180,
                     double hole_length_m_ = 0.600)
        : Obstacle(start_m_), depth_m(depth_m_),
          hole_length_m(hole_length_m_) {}
    [[nodiscard]] double length_m() const override {
        return hole_length_m;
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "Pothole";
    }
};

class Washboard final : public Obstacle {
public:
    double amplitude_m = 0.035;
    double wavelength_m = 0.900;
    int n_waves = 9;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit Washboard(double start_m_, double amplitude_m_ = 0.035,
                       double wavelength_m_ = 0.900, int n_waves_ = 9)
        : Obstacle(start_m_), amplitude_m(amplitude_m_),
          wavelength_m(wavelength_m_), n_waves(n_waves_) {}
    [[nodiscard]] double length_m() const override {
        return wavelength_m * static_cast<double>(n_waves);
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "Washboard";
    }
};

class GOut final : public Obstacle {
public:
    double depth_m = 0.350;
    double dip_length_m = 5.0;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit GOut(double start_m_, double depth_m_ = 0.350,
                  double dip_length_m_ = 5.0)
        : Obstacle(start_m_), depth_m(depth_m_),
          dip_length_m(dip_length_m_) {}
    [[nodiscard]] double length_m() const override {
        return dip_length_m;
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "GOut";
    }
};

class Drop final : public Obstacle {
public:
    double height_m = 0.600;
    double ramp_m = 0.0;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit Drop(double start_m_, double height_m_ = 0.600,
                  double ramp_m_ = 0.0)
        : Obstacle(start_m_), height_m(height_m_), ramp_m(ramp_m_) {}
    [[nodiscard]] double length_m() const override { return ramp_m; }
    [[nodiscard]] double datum_shift_m() const override {
        return -height_m;
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "Drop";
    }
};

class Kicker final : public Obstacle {
public:
    double height_m = 0.350;
    double ramp_m = 1.400;
    double gap_m = 2.500;
    double landing_angle_deg = 20.0;
    double landing_m = 3.000;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit Kicker(double start_m_, double height_m_ = 0.350,
                    double ramp_m_ = 1.400, double gap_m_ = 2.500,
                    double landing_angle_deg_ = 20.0,
                    double landing_m_ = 3.000)
        : Obstacle(start_m_), height_m(height_m_), ramp_m(ramp_m_),
          gap_m(gap_m_), landing_angle_deg(landing_angle_deg_),
          landing_m(landing_m_) {}
    [[nodiscard]] double length_m() const override {
        return ramp_m + gap_m + landing_m;
    }
    [[nodiscard]] double landing_drop_m() const {
        return landing_m * std::tan(detail::np_radians(landing_angle_deg));
    }
    [[nodiscard]] double launch_angle_deg() const {
        return detail::np_degrees(std::atan2(height_m, ramp_m));
    }
    [[nodiscard]] double datum_shift_m() const override {
        return -landing_drop_m();
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "Kicker";
    }
};

class Roots final : public Obstacle {
public:
    int n_bumps = 7;
    double height_m = 0.080;
    double width_m = 0.250;
    double section_length_m = 7.0;
    double jitter = 0.35;
    std::int64_t seed = 0;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit Roots(double start_m_, int n_bumps_ = 7,
                   double height_m_ = 0.080, double width_m_ = 0.250,
                   double section_length_m_ = 7.0, double jitter_ = 0.35,
                   std::int64_t seed_ = 0)
        : Obstacle(start_m_), n_bumps(n_bumps_), height_m(height_m_),
          width_m(width_m_), section_length_m(section_length_m_),
          jitter(jitter_), seed(seed_) {}
    [[nodiscard]] double length_m() const override {
        return section_length_m;
    }
    // bump_centres_m() — seeded jittered centres (grid-independent).
    [[nodiscard]] std::vector<double> bump_centres_m() const;
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "Roots";
    }
};

class RockGarden : public Obstacle {
public:
    double section_length_m = 8.0;
    double amplitude_m = 0.060;
    double correlation_length_m = 0.250;
    std::int64_t seed = 0;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit RockGarden(double start_m_, double section_length_m_ = 8.0,
                        double amplitude_m_ = 0.060,
                        double correlation_length_m_ = 0.250,
                        std::int64_t seed_ = 0)
        : Obstacle(start_m_), section_length_m(section_length_m_),
          amplitude_m(amplitude_m_),
          correlation_length_m(correlation_length_m_), seed(seed_) {}
    [[nodiscard]] double length_m() const override {
        return section_length_m;
    }
    // _nodes(): (s_nodes, z_nodes) — seeded correlated roughness nodes;
    // consumed verbatim by contact_safety.py's concave_span_deg.
    [[nodiscard]] virtual std::pair<std::vector<double>, std::vector<double>>
    nodes() const;
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "RockGarden";
    }
};

class Bump final : public Obstacle {
public:
    double height_m = 0.050;
    double bump_length_m = 0.400;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit Bump(double start_m_, double height_m_ = 0.050,
                  double bump_length_m_ = 0.400)
        : Obstacle(start_m_), height_m(height_m_),
          bump_length_m(bump_length_m_) {}
    [[nodiscard]] double length_m() const override {
        return bump_length_m;
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "Bump";
    }
};

class TrapezoidBump final : public Obstacle {
public:
    double height_m = 0.050;
    double ramp_m = 0.150;
    double plateau_m = 0.300;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit TrapezoidBump(double start_m_, double height_m_ = 0.050,
                           double ramp_m_ = 0.150, double plateau_m_ = 0.300)
        : Obstacle(start_m_), height_m(height_m_), ramp_m(ramp_m_),
          plateau_m(plateau_m_) {}
    [[nodiscard]] double length_m() const override {
        return 2.0 * ramp_m + plateau_m;
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "TrapezoidBump";
    }
};

class SlopedPothole final : public Obstacle {
public:
    double depth_m = 0.080;
    double hole_length_m = 0.500;
    double edge_m = 0.100;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit SlopedPothole(double start_m_, double depth_m_ = 0.080,
                           double hole_length_m_ = 0.500,
                           double edge_m_ = 0.100)
        : Obstacle(start_m_), depth_m(depth_m_),
          hole_length_m(hole_length_m_), edge_m(edge_m_) {}
    [[nodiscard]] double length_m() const override {
        return hole_length_m;
    }
    [[nodiscard]] double effective_edge_m() const {
        return detail::py_min2(edge_m, hole_length_m / 2.0);
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "SlopedPothole";
    }
};

class BowlPothole final : public Obstacle {
public:
    double depth_m = 0.080;
    double hole_length_m = 0.500;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit BowlPothole(double start_m_, double depth_m_ = 0.080,
                         double hole_length_m_ = 0.500)
        : Obstacle(start_m_), depth_m(depth_m_),
          hole_length_m(hole_length_m_) {}
    [[nodiscard]] double length_m() const override {
        return hole_length_m;
    }
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "BowlPothole";
    }
};

class RoadRoughness final : public RockGarden {
public:
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit RoadRoughness(double start_m_, double section_length_m_ = 10.0,
                           double amplitude_m_ = 0.003,
                           double correlation_length_m_ = 0.200,
                           std::int64_t seed_ = 0)
        : RockGarden(start_m_, section_length_m_, amplitude_m_,
                     correlation_length_m_, seed_) {}
    // Out-of-line in obstacles.cpp — the class key function.
    [[nodiscard]] bool annotate() const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "RoadRoughness";
    }
};

class SteppedClimb final : public Obstacle {
public:
    std::vector<std::array<double, 2>> steps = {
        {5.0, 15.0}, {10.0, 15.0}, {15.0, 15.0}, {20.0, 15.0}, {25.0, 15.0}};
    double transition_m = 3.0;
    // NOLINTNEXTLINE(bugprone-easily-swappable-parameters) positional args mirror the dataclass field order
    explicit SteppedClimb(
            double start_m_,
            std::vector<std::array<double, 2>> steps_ =
                    {{5.0, 15.0},
                     {10.0, 15.0},
                     {15.0, 15.0},
                     {20.0, 15.0},
                     {25.0, 15.0}},
            double transition_m_ = 3.0)
        : Obstacle(start_m_), steps(std::move(steps_)),
          transition_m(transition_m_) {}
    [[nodiscard]] double length_m() const override;
    [[nodiscard]] double datum_shift_m() const override;
    void elevation(std::span<const double> s,
                   std::span<double> out) const override;
public:
    [[nodiscard]] std::string_view class_name() const override {
        return "SteppedClimb";
    }
};

// ---------------------------------------------------------------------------
// profile.py — the track record (methods live in profile.cpp).
// ---------------------------------------------------------------------------

struct TrackSpec {
    std::string name;
    double length_m = 0.0;
    std::vector<std::shared_ptr<Obstacle>> obstacles;
    std::string description;
    std::string surface = std::string(DEFAULT_SURFACE);
    std::optional<GradeProfile> grade_profile;
    std::vector<SurfaceSection> surface_sections;

    // surface_map property (profile.py:42-44) — rebuilt and re-validated
    // on every access like the oracle.
    [[nodiscard]] SurfaceMap surface_map() const;
    // sorted_obstacles (stable by start_m).
    [[nodiscard]] std::vector<std::shared_ptr<Obstacle>>
    sorted_obstacles() const;
    // Net road-level change: sum(obstacle shifts, obstacles order)
    // + grade.elevation(length_m).
    [[nodiscard]] double datum_shift_m() const;
    // (position, label) pairs for annotate()==true obstacles.
    [[nodiscard]] std::vector<std::pair<double, std::string>>
    markers() const;
    // validate() — the ordered checks of profile.py:65-104 with the
    // oracle's exact message text.
    void validate() const;
};

// ---------------------------------------------------------------------------
// heightfield.py — fixed field geometry.
// ---------------------------------------------------------------------------

inline constexpr double DEFAULT_RESOLUTION_M = 0.005;
inline constexpr double FIELD_RUNOUT_MARGIN_M = 5.0;
inline constexpr double FIELD_LENGTH_STEP_M = 10.0;

struct HeightFieldSpec {
    int nrow = 2;
    int ncol = 24001;
    double radius_x_m = 60.0;
    double radius_y_m = 0.5;
    double elevation_m = 3.4;
    double base_m = 0.5;
    double datum_z_m = 2.8;

    [[nodiscard]] double track_length_m() const {
        return 2.0 * radius_x_m;
    }
    [[nodiscard]] double resolution_m() const {
        return track_length_m() / static_cast<double>(ncol - 1);
    }
    [[nodiscard]] double min_profile_m() const { return -datum_z_m; }
    [[nodiscard]] double max_profile_m() const {
        return elevation_m - datum_z_m;
    }
    [[nodiscard]] std::string size_attr() const;
    [[nodiscard]] std::vector<double> track_x() const;
    [[nodiscard]] double geom_x_m() const { return radius_x_m; }
    [[nodiscard]] double geom_z_m(double ground_z_m) const {
        return ground_z_m - datum_z_m;
    }
    [[nodiscard]] double catch_plane_z_m(double ground_z_m,
                                         double clearance_m = 1.0) const {
        return geom_z_m(ground_z_m) - clearance_m;
    }
    [[nodiscard]] bool fits(std::array<double, 2> extent_m) const {
        return extent_m[0] >= min_profile_m() &&
               extent_m[1] <= max_profile_m();
    }
    // normalize(profile_m): (nrow, ncol) [0,1] grid, row-major.
    [[nodiscard]] std::vector<double>
    normalize(std::span<const double> profile_m) const;
    // with_length(): a resized copy or the oracle's ValueError.
    [[nodiscard]] HeightFieldSpec with_length(double field_length_m) const;
    [[nodiscard]] static HeightFieldSpec
    for_track_length(double track_length_m_);
    [[nodiscard]] static HeightFieldSpec for_track(const TrackSpec &track);
    [[nodiscard]] bool is_default() const {
        return nrow == 2 && ncol == 24001 && radius_x_m == 60.0 &&
               radius_y_m == 0.5 && elevation_m == 3.4 && base_m == 0.5 &&
               datum_z_m == 2.8;
    }
};

// FIELD — the shipped default field (heightfield.py:236).
inline const HeightFieldSpec FIELD{};

// ---------------------------------------------------------------------------
// road.py — the procedural rough-road generator spec.
// ---------------------------------------------------------------------------

inline constexpr std::array<std::string_view, 3> POTHOLE_EDGES = {
    "sharp", "sloped", "bowl"};
inline constexpr std::array<std::string_view, 2> BUMP_SHAPES = {
    "cosine", "trapezoid"};
inline constexpr double DEFAULT_ROAD_LENGTH_M = 100.0;
inline constexpr double MIN_ROUGHNESS_SEGMENT_CORRELATIONS = 4.0;
inline constexpr double SIZE_ROUNDING_M = 0.001;
inline constexpr double POSITION_ROUNDING_M = 0.01;

// Insertion-ordered name→weight map: Python dict semantics matter — the
// weight-sum and negative-entry checks iterate in insertion order, while
// _choose sorts the names.
using WeightMap = std::vector<std::pair<std::string, double>>;

struct RoadGeneratorSpec {
    std::int64_t seed = 0;
    double runup_m = 10.0;
    double runout_m = 5.0;
    double min_gap_m = 1.0;

    double potholes_per_100m = 4.0;
    std::array<double, 2> pothole_depth_m = {0.040, 0.120};
    std::array<double, 2> pothole_length_m = {0.300, 0.800};
    WeightMap pothole_edge = {{"sharp", 1.0}};
    double pothole_edge_m = 0.100;

    double bumps_per_100m = 6.0;
    std::array<double, 2> bump_height_m = {0.030, 0.080};
    std::array<double, 2> bump_length_m = {0.300, 0.600};
    WeightMap bump_shape = {{"cosine", 1.0}};
    double bump_ramp_fraction = 0.3;

    double roughness_m = 0.003;
    double roughness_correlation_m = 0.200;

    // validate() — road.py:76-95 ordered checks with oracle message text.
    void validate() const;
};

} // namespace bike::terrain
