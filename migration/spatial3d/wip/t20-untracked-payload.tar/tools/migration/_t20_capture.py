#!/usr/bin/env python3
"""T20 one-shot capture: freeze terrain-primitive oracle behaviour.

Writes bitwise float64 payloads plus small JSON documents for the parts of
src/bike_sim/terrain the manifest's preset profiles do not already pin:

    terrain/obstacle_*.f64 + obstacle_elevations.json
        — per-class elevation grids (local s with ±5 cm margins) plus the
          param records the C++ test reconstructs from
    terrain/rock_nodes_seed*.f64 — RockGarden._nodes() output (n,2)
    terrain/roots_centres_2029.f64 — Roots.bump_centres_m() output
    terrain/track_fields.json    — TrackSpec markers/datum/extent/surface-map
    terrain/<preset>_profile_dense.f64 — build_profile over arange(0, L+res/2, res)
    terrain/road_obstacles.json  — generate_road layouts (spec + type/params)
    terrain/grade.f64            — slope/elevation pairs on a probe grid
    terrain/surface.json         — mu()/slip_stiffness/at() probes
    terrain/heightfield.json + field_data_*.f64 + track_x_default.f64
        — spec fields + build_field_data + track_x
    terrain/wheelpath_*.f64 + wheelpath.json
        — wheel-centre paths + drop/rise/bridged scalars
    terrain/contact_safety.json  — hazard strings + guard scalars
    terrain/profile_kernels.json — SignedProfile/ProfileQuery oracle rows
    terrain/validation.json      — exact exception kinds/messages

Manifest entries are appended by a second pass (tools/migration/_t20_manifest.py).
"""
from __future__ import annotations

import json
import struct
import sys
from dataclasses import asdict
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "src"))

import numpy as np  # noqa: E402

from bike_sim.terrain.obstacles import (  # noqa: E402
    BowlPothole, Bump, Drop, GOut, Kicker, Pothole, RoadRoughness,
    RockGarden, Roots, SlopedPothole, SquareEdge, SteppedClimb,
    TrapezoidBump, Washboard)
from bike_sim.terrain.profile import (  # noqa: E402
    TrackSpec, build_profile, profile_extent)
from bike_sim.terrain.grade import GradeProfile  # noqa: E402
from bike_sim.terrain.heightfield import (  # noqa: E402
    FIELD, HeightFieldSpec, assert_track_fits, build_field_data)
from bike_sim.terrain.surface import (  # noqa: E402
    SURFACES, SurfaceMap, SurfaceSection, get_surface, slip_stiffness_n)
from bike_sim.terrain.wheelpath import (  # noqa: E402
    bridged_drop_m, effective_drop_m, effective_rise_m, wheel_centre_path)
from bike_sim.terrain.contact_safety import (  # noqa: E402
    concave_span_deg, max_bowl_depth_m, min_bump_length_m,
    single_contact_hazards)
from bike_sim.terrain.profile_distance import SignedProfile  # noqa: E402
from bike_sim.terrain.contact_profile import ProfileQuery  # noqa: E402
from bike_sim.terrain import presets as terrain_presets  # noqa: E402
from bike_sim.terrain.road import (  # noqa: E402
    RoadGeneratorSpec, build_road, generate_road, road_broken_spec,
    road_smooth_spec, road_worn_spec)

OUT = REPO / "tests" / "fixtures" / "migration" / "terrain"


def f64(path: str, arr) -> None:
    a = np.asarray(arr, dtype=np.float64, order="C")
    OUT.joinpath(path).write_bytes(
        struct.pack(f"<{a.size}d", *a.ravel()))


def _encode_tree(obj):
    """Canonical tagged tree: non-finite floats -> {"$nonfinite": "nan"|
    "inf"|"-inf"} so the output is strict JSON (allow_nan=False)."""
    if isinstance(obj, dict):
        return {k: _encode_tree(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_encode_tree(v) for v in obj]
    if isinstance(obj, float) and not np.isfinite(obj):
        return {"$nonfinite": ("nan" if np.isnan(obj)
                               else "inf" if obj > 0 else "-inf")}
    return obj


def js(path: str, obj) -> None:
    OUT.joinpath(path).write_text(
        json.dumps(_encode_tree(obj), indent=1, sort_keys=True,
                   allow_nan=False) + "\n")


def obstacle_record(o) -> dict:
    rec = {"type": type(o).__name__}
    rec.update(asdict(o))
    return rec


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)

    # --- obstacle elevation grids (local s; margins beyond [0, length]) ---
    cases = [
        ("square_edge", SquareEdge(start_m=5.0)),
        ("square_edge_authored", SquareEdge(start_m=20.0, height_m=0.070,
                                            ledge_length_m=0.250)),
        ("pothole", Pothole(start_m=38.0)),
        ("washboard9", Washboard(start_m=12.0)),
        ("washboard20", Washboard(start_m=15.0, n_waves=20)),
        ("g_out", GOut(start_m=42.0)),
        ("drop", Drop(start_m=52.0)),
        ("drop_ramp", Drop(start_m=52.0, height_m=0.600, ramp_m=0.75)),
        ("kicker", Kicker(start_m=57.0, landing_m=5.0)),
        ("kicker_default", Kicker(start_m=57.0)),
        ("roots2029", Roots(start_m=69.0, seed=2029)),
        ("rock1701", RockGarden(start_m=26.0, seed=1701)),
        ("rock3301", RockGarden(start_m=84.0, section_length_m=11.0,
                                amplitude_m=0.09, correlation_length_m=0.2,
                                seed=3301)),
        ("bump", Bump(start_m=30.0)),
        ("trapezoid", TrapezoidBump(start_m=30.0)),
        ("trapezoid_sharp", TrapezoidBump(start_m=30.0, height_m=0.05,
                                          ramp_m=0.0, plateau_m=0.3)),
        ("sloped_pothole", SlopedPothole(start_m=30.0)),
        ("sloped_pothole_wide_edge",
         SlopedPothole(start_m=30.0, edge_m=0.4)),
        ("bowl_pothole", BowlPothole(start_m=30.0)),
        ("road_roughness", RoadRoughness(start_m=10.0, seed=17)),
        ("stepped_climb", SteppedClimb(start_m=15.0)),
        ("stepped_climb_short",
         SteppedClimb(start_m=15.0, steps=((8.0, 10.0), (16.0, 10.0)),
                      transition_m=2.5)),
    ]
    doc = {"cases": []}
    for name, obs in cases:
        s = np.arange(-0.05, obs.length_m + 0.05 + 0.0025, 0.005)
        f64(f"obstacle_{name}.f64",
            np.column_stack((s, obs.elevation(s))))
        rec = obstacle_record(obs)
        rec["length_m"] = obs.length_m
        rec["datum_shift_m"] = obs.datum_shift_m
        rec["label"] = obs.label
        rec["annotate"] = obs.annotate
        rec["grid"] = {"start": -0.05, "step": 0.005,
                       "stop": obs.length_m + 0.05 + 0.0025,
                       "count": int(len(s))}
        doc["cases"].append({"name": name, "record": rec})
    js("obstacle_elevations.json", doc)

    # --- RockGarden._nodes() — RNG + gaussian smoothing parity ----------
    for tag, kw in (("seed1701", {"seed": 1701}),
                    ("seed3301", {"seed": 3301, "section_length_m": 11.0,
                                  "amplitude_m": 0.09,
                                  "correlation_length_m": 0.2}),
                    ("seed0", {"seed": 0}),
                    ("rough17", {"seed": 17, "section_length_m": 10.0,
                                 "amplitude_m": 0.003,
                                 "correlation_length_m": 0.2})):
        rg = RockGarden(start_m=0.0, **kw)
        s, z = rg._nodes()
        f64(f"rock_nodes_{tag}.f64", np.column_stack((s, z)))

    rt = Roots(start_m=69.0, n_bumps=7, height_m=0.08, width_m=0.25,
               section_length_m=7.0, seed=2029)
    f64("roots_centres_2029.f64", rt.bump_centres_m())

    # --- dense build_profile over whole tracks --------------------------
    preset_tracks = {
        "flat": terrain_presets.flat(),
        "single_edge": terrain_presets.single_edge(),
        "washboard_only": terrain_presets.washboard_only(),
        "climb_steps": terrain_presets.climb_steps(),
        "enduro_aggressive": terrain_presets.enduro_aggressive(),
        "road_smooth": terrain_presets.road_smooth(),
        "road_worn": terrain_presets.road_worn(),
        "road_broken": terrain_presets.road_broken(),
    }
    fields = {"tracks": []}
    for name, track in preset_tracks.items():
        xs = np.arange(0.0, track.length_m + 0.0025, 0.005)
        f64(f"{name}_profile_dense.f64",
            np.column_stack((xs, build_profile(track, xs))))
        fields["tracks"].append({
            "name": name,
            "length_m": track.length_m,
            "datum_shift_m": track.datum_shift_m,
            "extent": list(profile_extent(track)),
            "markers": track.markers,
            "surface_map": track.surface_map.name,
        })
    js("track_fields.json", fields)

    # --- generate_road layouts ------------------------------------------
    road_doc = {"roads": []}
    custom_spec = RoadGeneratorSpec(
        seed=7, runup_m=8.0, runout_m=4.0, min_gap_m=0.75,
        potholes_per_100m=5.0, pothole_depth_m=(0.05, 0.11),
        pothole_length_m=(0.3, 0.7),
        pothole_edge={"sharp": 0.5, "sloped": 0.3, "bowl": 0.2},
        pothole_edge_m=0.05,
        bumps_per_100m=5.0, bump_height_m=(0.03, 0.07),
        bump_length_m=(0.3, 0.5),
        bump_shape={"cosine": 0.6, "trapezoid": 0.4},
        bump_ramp_fraction=0.25,
        roughness_m=0.004, roughness_correlation_m=0.15)
    for name, spec, length, reserved in (
            ("road_smooth", road_smooth_spec(), 100.0, ()),
            ("road_worn", road_worn_spec(), 100.0, ()),
            ("road_broken", road_broken_spec(), 100.0, ()),
            ("custom_reserved", custom_spec, 80.0, ((30.0, 33.0),))):
        generated = generate_road(spec, length, reserved)
        road_doc["roads"].append({
            "name": name,
            "length_m": length,
            "reserved": [list(r) for r in reserved],
            "spec": asdict(spec),
            "obstacles": [obstacle_record(o) for o in generated],
        })
    js("road_obstacles.json", road_doc)

    # --- grade profile ----------------------------------------------------
    gp = GradeProfile(((0.0, 0.0), (10.0, 0.0), (12.0, 0.177), (120.0, 0.0)))
    xg = np.concatenate((np.arange(-1.0, 1.0, 0.25),
                         np.arange(0.0, 14.0, 0.125),
                         np.linspace(14.0, 130.0, 89)))
    f64("grade.f64",
        np.column_stack((xg, gp.slope(xg), gp.elevation(xg))))

    # --- surfaces -----------------------------------------------------------
    speeds = [-9.0, -4.5, -0.001, 0.0, 0.001, 1.25, 4.5, 25.0]
    loads = [-1.0, 0.0, 1e-9, 800.0]
    surface_doc = {"speeds": speeds, "loads": loads,
                   "mu": {}, "slip": {}, "maps": {}}
    for name, spec in SURFACES.items():
        surface_doc["mu"][name] = [float(spec.mu(v)) for v in speeds]
        surface_doc["slip"][name] = [slip_stiffness_n(spec, k)
                                     for k in loads]
    surface_doc["specs"] = {n: asdict(s) for n, s in SURFACES.items()}
    sm = SurfaceMap(get_surface("hardpack"),
                    (SurfaceSection(5.0, 10.0, "wet"),
                     SurfaceSection(30.0, 40.0, "loose")))
    probes = [-0.5, 0.0, 4.999, 5.0, 9.999, 10.0, 29.999, 30.0, 39.999,
              40.0, 100.0]
    surface_doc["maps"]["hardpack_wet_loose"] = {
        "name": sm.name,
        "surfaces": [s.name for s in sm.surfaces],
        "probes": {repr(p): sm.at(p).name for p in probes},
        "probe_x": probes,
    }
    js("surface.json", surface_doc)

    # --- heightfield ---------------------------------------------------------
    long_track = TrackSpec(name="long", length_m=200.0, obstacles=[])
    grade_track = TrackSpec(
        name="gradey", length_m=40.0, obstacles=[],
        grade_profile=GradeProfile(((0.0, 0.0), (40.0, 0.3))))
    deep_track = TrackSpec(
        name="deep", length_m=60.0,
        obstacles=[Pothole(start_m=10.0, depth_m=3.5, hole_length_m=2.0),
                   SquareEdge(start_m=30.0, height_m=1.2,
                              ledge_length_m=1.0)])
    hf_doc = {"specs": {}, "geom": {}, "errors": []}
    for name, spec in (("default", FIELD),
                       ("for_flat112", HeightFieldSpec.for_track(
                           preset_tracks["flat"])),
                       ("for_long200", HeightFieldSpec.for_track(long_track)),
                       ("for_grade40", HeightFieldSpec.for_track(grade_track)),
                       ("for_deep60", HeightFieldSpec.for_track(deep_track)),
                       ("for_enduro", HeightFieldSpec.for_track(
                           preset_tracks["enduro_aggressive"]))):
        hf_doc["specs"][name] = {
            "nrow": spec.nrow, "ncol": spec.ncol,
            "radius_x_m": spec.radius_x_m, "radius_y_m": spec.radius_y_m,
            "elevation_m": spec.elevation_m, "base_m": spec.base_m,
            "datum_z_m": spec.datum_z_m,
            "track_length_m": spec.track_length_m,
            "resolution_m": spec.resolution_m,
            "min_profile_m": spec.min_profile_m,
            "max_profile_m": spec.max_profile_m,
            "size_attr": spec.size_attr,
            "is_default": spec.is_default,
        }
        hf_doc["geom"][name] = {
            "geom_x_m": spec.geom_x_m(),
            "geom_z_m": spec.geom_z_m(0.5),
            "catch_plane_z_m": spec.catch_plane_z_m(0.5),
        }
    f64("field_data_flat.f64", build_field_data(preset_tracks["flat"]))
    f64("field_data_enduro.f64",
        build_field_data(preset_tracks["enduro_aggressive"]))
    f64("field_data_long.f64", build_field_data(long_track))
    f64("track_x_default.f64", FIELD.track_x())
    try:
        FIELD.with_length(0.0375)
    except ValueError as exc:
        hf_doc["errors"].append(
            {"call": "with_length(0.0375)", "error": str(exc)})
    try:
        FIELD.with_length(0.037)
    except ValueError as exc:
        hf_doc["errors"].append(
            {"call": "with_length(0.037)", "error": str(exc)})
    try:
        FIELD.with_length(-2.0)
    except ValueError as exc:
        hf_doc["errors"].append(
            {"call": "with_length(-2.0)", "error": str(exc)})
    hf_doc["with_length_130"] = asdict(FIELD.with_length(130.0))
    fit_doc = {"errors": hf_doc["errors"]}
    for track in (long_track, deep_track):
        try:
            assert_track_fits(track)
        except ValueError as exc:
            fit_doc["errors"].append(
                {"call": f"assert_track_fits({track.name})",
                 "error": str(exc)})
    js("heightfield.json", fit_doc | {"specs": hf_doc["specs"],
                                    "geom": hf_doc["geom"],
                                    "with_length_130":
                                    hf_doc["with_length_130"]})

    # --- wheelpath ---------------------------------------------------------
    wp_doc = {"scalars": {}, "paths": {}}
    for name, obs in (("pothole", Pothole(start_m=0.0)),
                      ("bump", Bump(start_m=0.0)),
                      ("rock1701", RockGarden(start_m=0.0, seed=1701)),
                      ("drop_ramp", Drop(start_m=0.0, ramp_m=0.75)),
                      ("kicker", Kicker(start_m=0.0, landing_m=5.0))):
        xc, zc = wheel_centre_path(obs, 0.372)
        f64(f"wheelpath_{name}.f64", np.column_stack((xc, zc)))
        wp_doc["scalars"][name] = {
            "drop": effective_drop_m(obs, 0.372),
            "rise": effective_rise_m(obs, 0.372),
            "n": int(len(xc)),
        }
    wp_doc["bridged"] = {
        str(w): bridged_drop_m(w, 0.372)
        for w in (0.372, 0.5, 0.6, 0.7, 0.743, 0.744, 0.8, 1.5)}
    js("wheelpath.json", wp_doc)

    # --- contact safety ------------------------------------------------------
    safety = {"hazards": {}, "guards": {}, "concave": {}}
    safety["hazards"]["enduro_aggressive"] = single_contact_hazards(
        preset_tracks["enduro_aggressive"])
    hazard_track = TrackSpec(
        name="hazards", length_m=120.0,
        obstacles=[Bump(start_m=5.0, height_m=0.05, bump_length_m=0.4),
                   BowlPothole(start_m=10.0, depth_m=0.15,
                               hole_length_m=0.5),
                   GOut(start_m=20.0, depth_m=0.5, dip_length_m=1.0),
                   SquareEdge(start_m=30.0),
                   RoadRoughness(start_m=40.0, section_length_m=10.0,
                                 amplitude_m=0.003,
                                 correlation_length_m=0.2, seed=17),
                   Kicker(start_m=55.0, landing_m=5.0),
                   Roots(start_m=65.0, seed=2029),
                   TrapezoidBump(start_m=75.0),
                   SlopedPothole(start_m=80.0),
                   Pothole(start_m=85.0),
                   Washboard(start_m=90.0),
                   Drop(start_m=100.0),
                   SteppedClimb(start_m=105.0,
                                steps=((5.0, 4.0),), transition_m=1.0)])
    safety["hazards"]["custom"] = single_contact_hazards(hazard_track)
    safety["guards"]["min_bump_length_0.05"] = min_bump_length_m(0.05)
    safety["guards"]["min_bump_length_0.09"] = min_bump_length_m(0.09)
    safety["guards"]["max_bowl_depth_0.5"] = max_bowl_depth_m(0.5)
    safety["guards"]["max_bowl_depth_5.0"] = max_bowl_depth_m(5.0)
    safety["concave"]["rock1701"] = concave_span_deg(
        RockGarden(start_m=26.0, seed=1701))
    safety["concave"]["rock3301"] = concave_span_deg(
        RockGarden(start_m=84.0, section_length_m=11.0, amplitude_m=0.09,
                   correlation_length_m=0.2, seed=3301))
    safety["concave"]["road_roughness17"] = concave_span_deg(
        RoadRoughness(start_m=40.0, section_length_m=10.0,
                      amplitude_m=0.003, correlation_length_m=0.2, seed=17))
    js("contact_safety.json", safety)

    # --- contact profile + signed distance reuse probes -------------------
    verts = np.array([
        [0.0, 0.0], [1.0, 0.0], [1.5, -0.18], [2.1, -0.18], [2.6, 0.0],
        [4.0, 0.0], [4.3, 0.09], [4.55, 0.09], [4.8, 0.0], [6.0, 0.0]])
    sp = SignedProfile(verts)
    pq = ProfileQuery(verts)
    kernels = {"distance": [], "contact": [], "height": []}
    for p in ([0.5, 0.4], [1.25, 0.1], [1.6, -0.05], [1.8, 0.3],
              [2.0, -0.5], [3.0, 0.05], [4.4, 0.2], [4.5, 0.05],
              [5.9, -0.2], [0.5, -0.05]):
        r = sp.query(np.array([[p[0], p[1]]]))
        kernels["distance"].append({
            "point": list(p),
            "distance": float(r.distance[0]),
            "normal": [float(v) for v in r.normal[0]],
            "closest": [float(v) for v in r.point[0]],
            "segment": int(r.segment[0]),
            "nonsmooth": bool(r.nonsmooth[0]),
        })
    for xq in (0.0, 0.5, 1.0, 1.25, 1.5, 2.35, 4.4, 4.55, 6.0):
        kernels["height"].append(
            {"x": xq, "z": float(sp.height(np.asarray(xq)))})
    for c, rad, prev in (([0.5, 0.372], 0.372, None),
                         ([1.8, 0.20], 0.372, None),
                         ([1.8, 0.15], 0.372, 2),
                         ([4.4, 0.40], 0.372, None),
                         ([4.45, 0.46], 0.372, 6),
                         ([2.0, 0.10], 0.352, None),
                         ([5.5, 0.5], 0.352, None),
                         ([1.6, 0.24], 0.372, None),
                         ([4.6, 0.47], 0.372, None)):
        ct = pq.contact(np.array(c), rad, prev)
        kernels["contact"].append({
            "center": list(c), "radius": rad, "previous": prev,
            "point": [float(v) for v in ct.point],
            "normal": [float(v) for v in ct.normal],
            "delta": float(ct.delta),
            "segment_id": int(ct.segment_id),
            "multi_support": bool(ct.multi_support),
        })
    kernels["vertices"] = verts.tolist()
    js("profile_kernels.json", kernels)

    # --- validation/error-message captures ---------------------------------
    errors = []

    def capture(label, fn):
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            errors.append({"case": label,
                           "error": type(exc).__name__,
                           "message": str(exc)})
        else:
            errors.append({"case": label, "error": None,
                           "message": None})

    capture("track_zero_length",
            lambda: TrackSpec(name="t", length_m=0.0).validate())
    capture("track_negative_length",
            lambda: TrackSpec(name="t", length_m=-2.5).validate())
    capture("track_inf_length",
            lambda: TrackSpec(name="t", length_m=float("inf")).validate())
    capture("track_unknown_surface",
            lambda: TrackSpec(name="bad", length_m=10.0,
                              surface="ice").validate())
    capture("obstacle_outside",
            lambda: TrackSpec(
                name="t", length_m=10.0,
                obstacles=[SquareEdge(start_m=9.9, ledge_length_m=0.25)]
            ).validate())
    capture("obstacle_negative_start",
            lambda: TrackSpec(
                name="t", length_m=10.0,
                obstacles=[SquareEdge(start_m=-0.5)]).validate())
    capture("obstacle_overlap",
            lambda: TrackSpec(
                name="t", length_m=30.0,
                obstacles=[Washboard(start_m=5.0, n_waves=9),
                           Pothole(start_m=12.0)]).validate())
    capture("obstacle_touch_ok",
            lambda: TrackSpec(
                name="t", length_m=30.0,
                obstacles=[Pothole(start_m=5.0, hole_length_m=0.5),
                           Pothole(start_m=5.5)]).validate())
    capture("grade_single_knot", lambda: GradeProfile(((0.0, 0.1),)))
    capture("grade_nonzero_start", lambda: GradeProfile(((1.0, 0.1),
                                                         (2.0, 0.2))))
    capture("grade_decreasing", lambda: GradeProfile(((0.0, 0.1),
                                                      (0.0, 0.2))))
    capture("grade_nan_knot", lambda: GradeProfile(((0.0, 0.1),
                                                    (5.0, float("nan")))))
    capture("grade_beyond_track",
            lambda: TrackSpec(
                name="t", length_m=5.0,
                grade_profile=GradeProfile(((0.0, 0.0), (10.0, 0.1))))
            .validate())
    capture("grade_query_nan", lambda: GradeProfile(
        ((0.0, 0.0), (10.0, 0.1))).slope(float("nan")))
    capture("surface_section_reversed",
            lambda: SurfaceSection(5.0, 2.0, "wet"))
    capture("surface_section_negative",
            lambda: SurfaceSection(-1.0, 2.0, "wet"))
    capture("surface_section_unknown",
            lambda: SurfaceSection(0.0, 2.0, "ice"))
    capture("surface_section_nan",
            lambda: SurfaceSection(0.0, float("nan"), "wet"))
    capture("surface_map_overlap",
            lambda: SurfaceMap(get_surface("hardpack"),
                               (SurfaceSection(5.0, 10.0, "wet"),
                                SurfaceSection(9.0, 12.0, "loose"))))
    capture("surface_map_touch_ok",
            lambda: SurfaceMap(get_surface("hardpack"),
                               (SurfaceSection(5.0, 10.0, "wet"),
                                SurfaceSection(10.0, 12.0, "loose"))))
    capture("material_beyond_track",
            lambda: TrackSpec(
                name="t", length_m=8.0,
                surface_sections=(SurfaceSection(5.0, 10.0, "wet"),))
            .validate())
    capture("get_surface_unknown", lambda: get_surface("ice"))
    capture("surface_spec_negative",
            lambda: type(SURFACES["wet"])(
                name="bad", mu_peak=-1.0, mu_slide=0.4,
                slip_stiffness_per_load=10.0))
    capture("surface_spec_slide_over_peak",
            lambda: type(SURFACES["wet"])(
                name="bad", mu_peak=0.4, mu_slide=0.5,
                slip_stiffness_per_load=10.0))
    capture("surface_spec_nan",
            lambda: type(SURFACES["wet"])(
                name="bad", mu_peak=float("nan"), mu_slide=0.4,
                slip_stiffness_per_load=10.0))
    capture("surface_mu_nan",
            lambda: SURFACES["asphalt"].mu(float("nan")))
    capture("surface_mu_inf",
            lambda: SURFACES["asphalt"].mu(float("inf")))
    capture("map_at_nan", lambda: sm.at(float("nan")))
    capture("road_negative_rate",
            lambda: RoadGeneratorSpec(potholes_per_100m=-1.0).validate())
    capture("road_inverted_range",
            lambda: RoadGeneratorSpec(
                pothole_depth_m=(0.5, 0.2)).validate())
    capture("road_negative_range_end",
            lambda: RoadGeneratorSpec(
                bump_length_m=(-0.5, 0.2)).validate())
    capture("road_bad_edge_name",
            lambda: RoadGeneratorSpec(
                pothole_edge={"bogus": 1.0}).validate())
    capture("road_zero_weights",
            lambda: RoadGeneratorSpec(pothole_edge={}).validate())
    capture("road_negative_weight",
            lambda: RoadGeneratorSpec(
                pothole_edge={"sharp": -0.5, "sloped": 2.0}).validate())
    capture("road_bad_ramp_fraction",
            lambda: RoadGeneratorSpec(bump_ramp_fraction=0.7).validate())
    capture("road_no_room",
            lambda: generate_road(RoadGeneratorSpec(seed=0), 5.0, ()))
    capture("heightfield_wrong_count",
            lambda: FIELD.normalize(np.zeros(5)))
    capture("heightfield_extent_escape",
            lambda: FIELD.normalize(np.linspace(-4.0, 0.0, 24001)))
    capture("profile_query_nan_center",
            lambda: ProfileQuery(np.array([[0., 0.], [1., 0.]]))
            .contact(np.array([float("nan"), 0.5]), 0.372, None))
    capture("profile_query_below_road",
            lambda: ProfileQuery(np.array([[0., 0.], [1., 0.]]))
            .contact(np.array([0.5, -0.1]), 0.372, None))
    capture("profile_query_outside",
            lambda: ProfileQuery(np.array([[0., 0.], [1., 0.]]))
            .contact(np.array([2.0, 0.5]), 0.372, None))
    capture("profile_query_bad_radius",
            lambda: ProfileQuery(np.array([[0., 0.], [1., 0.]]))
            .contact(np.array([0.5, 0.5]), 0.0, None))
    capture("profile_query_degenerate",
            lambda: ProfileQuery(np.array([[0., 0.], [1., 0.]]))
            .contact(np.array([0.5, 1e-14]), 0.372, None))
    capture("profile_query_bad_vertices",
            lambda: ProfileQuery(np.array([[0., 0.]])))
    capture("profile_query_dup_x",
            lambda: ProfileQuery(np.array([[0., 0.], [0.5, 0.],
                                           [0.5, 1.]])))
    capture("signed_profile_bad_vertices",
            lambda: SignedProfile(np.array([[0., 0.], [0., 1.]])))
    capture("signed_profile_duplicate_x",
            lambda: SignedProfile(np.array([[0., 0.], [0.5, 0.],
                                            [0.5, 1.]])))
    capture("signed_profile_nonfinite",
            lambda: SignedProfile(np.array([[0., 0.], [0.5, float("nan")]])))
    capture("signed_profile_height_outside",
            lambda: sp.height(6.5))
    capture("signed_profile_height_nan",
            lambda: sp.height(float("nan")))
    capture("signed_profile_query_bad",
            lambda: sp.query(np.array([0.1, 0.2])))
    scalars = {
        "stepped_climb_datum": SteppedClimb(start_m=15.0).datum_shift_m,
        "stepped_climb_short_datum":
            SteppedClimb(start_m=15.0, steps=((8.0, 10.0), (16.0, 10.0)),
                         transition_m=2.5).datum_shift_m,
        "kicker_launch_angle":
            Kicker(start_m=57.0, landing_m=5.0).launch_angle_deg,
        "kicker_landing_drop":
            Kicker(start_m=57.0, landing_m=5.0).landing_drop_m,
        "kicker_default_landing_drop":
            Kicker(start_m=57.0).landing_drop_m,
    }
    js("validation.json", {"cases": errors, "scalars": scalars})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
